
"""
Simple training script for Intelligent Ticket Triage Agent
This script trains a model and saves it to the models folder
"""

import pandas as pd
import numpy as np
import pickle
import re
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# Configuration
RANDOM_SEED = 42
MODEL_PATH = Path("models/model.pkl")
VECTORIZER_PATH = Path("models/vectorizer.pkl")

# Create models directory if it doesn't exist
MODEL_PATH.parent.mkdir(exist_ok=True)

def clean_text(text):
    """Clean text for training"""
    if pd.isna(text) or not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r"[^a-zA-Z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def create_sample_data():
    """Create sample training data if no CSV is provided"""
    print("\n📝 Creating sample training data...")
    
    training_data = [
        # Billing (15 samples)
        ("I was charged twice for my subscription", "Billing"),
        ("Please refund the duplicate payment", "Billing"),
        ("My invoice shows wrong amount", "Billing"),
        ("Can't update my payment method", "Billing"),
        ("When will I get my money back", "Billing"),
        ("My credit card was declined", "Billing"),
        ("Need a copy of my receipt", "Billing"),
        ("The price increased without notice", "Billing"),
        ("Discount code not working", "Billing"),
        ("I was charged after canceling", "Billing"),
        ("Payment method expired", "Billing"),
        ("International transaction fee", "Billing"),
        ("Upgraded but charged old price", "Billing"),
        ("Invoice missing from account", "Billing"),
        ("Annual subscription renewal", "Billing"),
        
        # Technical (15 samples)
        ("The application crashes when I try to login", "Technical"),
        ("Database connection error occurred", "Technical"),
        ("Server is down, cannot access the system", "Technical"),
        ("API returns 500 error", "Technical"),
        ("Page loads very slowly", "Technical"),
        ("Mobile app crashes on startup", "Technical"),
        ("Export function not working", "Technical"),
        ("File upload fails", "Technical"),
        ("Email notifications not sending", "Technical"),
        ("Search functionality broken", "Technical"),
        ("Data not syncing", "Technical"),
        ("Login session expires", "Technical"),
        ("Integration failing", "Technical"),
        ("SSL certificate error", "Technical"),
        ("Memory leak issue", "Technical"),
        
        # Account (15 samples)
        ("I forgot my password", "Account"),
        ("Can't login to my account", "Account"),
        ("Someone hacked my account", "Account"),
        ("How to change my email", "Account"),
        ("Account locked after multiple attempts", "Account"),
        ("Two-factor authentication not working", "Account"),
        ("Cannot change profile information", "Account"),
        ("Unable to deactivate account", "Account"),
        ("Permission denied", "Account"),
        ("Account verification not working", "Account"),
        ("Role change request", "Account"),
        ("Cannot connect social media", "Account"),
        ("Account suspended", "Account"),
        ("Username already taken", "Account"),
        ("Account settings not saving", "Account"),
        
        # Delivery (15 samples)
        ("My package hasn't arrived", "Delivery"),
        ("Where is my order", "Delivery"),
        ("Shipping was delayed", "Delivery"),
        ("Wrong item delivered", "Delivery"),
        ("Tracking number not working", "Delivery"),
        ("Package damaged during shipping", "Delivery"),
        ("Delivery address incorrect", "Delivery"),
        ("Partial shipment received", "Delivery"),
        ("Customs clearance delay", "Delivery"),
        ("Return label not working", "Delivery"),
        ("International shipping cost", "Delivery"),
        ("Expedited shipping not processed", "Delivery"),
        ("Delivery date changed", "Delivery"),
        ("Package marked delivered but not received", "Delivery"),
        ("Delivery to wrong address", "Delivery"),
        
        # General (15 samples)
        ("How does this work", "General"),
        ("Need help with your service", "General"),
        ("What are your business hours", "General"),
        ("Contact support please", "General"),
        ("Thanks for your help", "General"),
        ("Do you offer phone support", "General"),
        ("Where can I find documentation", "General"),
        ("Is there a mobile app", "General"),
        ("Can I export my data", "General"),
        ("How to cancel subscription", "General"),
        ("Privacy policy questions", "General"),
        ("Feature request", "General"),
        ("Tutorial videos", "General"),
        ("System requirements", "General"),
        ("Partnership opportunities", "General"),
    ]
    
    return training_data

def load_csv_data():
    """Try to load CSV data if available"""
    csv_path = input("\n📁 Enter path to CSV file (or press Enter to skip): ").strip()
    
    if not csv_path:
        return []
    
    if not Path(csv_path).exists():
        print(f"⚠️ File not found: {csv_path}")
        return []
    
    try:
        df = pd.read_csv(csv_path)
        print(f"\n✅ Loaded {len(df)} rows from CSV")
        print(f"Columns: {list(df.columns)}")
        
        # Assume first column is text, second is category
        text_col = df.columns[0]
        category_col = df.columns[1]
        
        print(f"Using '{text_col}' for text")
        print(f"Using '{category_col}' for category")
        
        # Clean data
        texts = df[text_col].fillna("").astype(str).apply(clean_text).tolist()
        categories = df[category_col].fillna("").astype(str).tolist()
        
        # Filter out empty
        valid_data = [(t, c) for t, c in zip(texts, categories) if t and len(t) > 5]
        print(f"Valid samples: {len(valid_data)}")
        
        return valid_data
        
    except Exception as e:
        print(f"❌ Error loading CSV: {e}")
        return []

def main():
    print("="*60)
    print("TICKET TRIAGE MODEL TRAINING")
    print("="*60)
    
    # Try to load CSV data first
    csv_data = load_csv_data()
    
    # Create sample data
    sample_data = create_sample_data()
    
    # Combine data
    if csv_data:
        all_data = csv_data + sample_data
        print(f"\n📊 Total training samples: {len(all_data)} (CSV: {len(csv_data)} + Sample: {len(sample_data)})")
    else:
        all_data = sample_data
        print(f"\n📊 Using sample data only: {len(all_data)} samples")
    
    # Prepare data
    texts = [item[0] for item in all_data]
    labels = [item[1] for item in all_data]
    
    # Show category distribution
    from collections import Counter
    dist = Counter(labels)
    print("\n📈 Category Distribution:")
    for category in ['Billing', 'Technical', 'Account', 'Delivery', 'General']:
        count = dist.get(category, 0)
        percentage = (count / len(labels)) * 100
        print(f"   {category}: {count} ({percentage:.1f}%)")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.2, random_state=RANDOM_SEED
    )
    
    print(f"\n📊 Training: {len(X_train)} samples")
    print(f"📊 Testing: {len(X_test)} samples")
    
    # Create vectorizer
    print("\n🔄 Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        max_features=1000,
        ngram_range=(1, 2),
        stop_words='english',
        lowercase=True
    )
    
    X_train_vec = vectorizer.fit_transform(X_train)
    print(f"   Vocabulary size: {len(vectorizer.vocabulary_)}")
    
    # Train classifier
    print("\n🔄 Training Logistic Regression classifier...")
    classifier = LogisticRegression(
        max_iter=1000,
        random_state=RANDOM_SEED,
        multi_class='multinomial',
        solver='lbfgs'
    )
    
    classifier.fit(X_train_vec, y_train)
    
    # Evaluate
    X_test_vec = vectorizer.transform(X_test)
    accuracy = classifier.score(X_test_vec, y_test)
    print(f"\n✅ Test Accuracy: {accuracy:.2%}")
    
    # Save model
    print("\n💾 Saving model...")
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(classifier, f)
    
    with open(VECTORIZER_PATH, 'wb') as f:
        pickle.dump(vectorizer, f)
    
    print(f"✅ Model saved to: {MODEL_PATH}")
    print(f"✅ Vectorizer saved to: {VECTORIZER_PATH}")
    
    # Test with sample queries
    print("\n" + "="*60)
    print("TESTING MODEL")
    print("="*60)
    
    test_queries = [
        "I was charged twice",
        "The app crashes on login",
        "I forgot my password",
        "Where is my package?",
        "How do I use this?",
        "Security issue with account",
        "Payment not going through",
        "Delivery address wrong",
    ]
    
    for query in test_queries:
        cleaned = clean_text(query)
        X_test = vectorizer.transform([cleaned])
        pred = classifier.predict(X_test)[0]
        proba = classifier.predict_proba(X_test).max()
        print(f"\n📝 {query}")
        print(f"   → {pred} ({proba:.2%})")
    
    print("\n" + "="*60)
    print("✅ TRAINING COMPLETE!")
    print("="*60)
    print("\nRun the app with: streamlit run app.py")

if __name__ == "__main__":
    main()
