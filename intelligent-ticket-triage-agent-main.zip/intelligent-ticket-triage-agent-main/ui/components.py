
"""Reusable UI components with animations."""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from ui.theme import STATE_COLORS, PRIORITY_COLORS, get_state_badge, get_priority_badge


def render_final_result(result):
    """Render final triage result with animation."""
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        category = result.get('classification', {}).get('category', 'unknown')
        st.markdown(f"""
        <div class="glass-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 2rem;">📑</div>
            <h3 style="margin: 0; color: #4b5563;">Category</h3>
            <h2 class="gradient-text" style="margin: 0; font-size: 1.5rem;">{category.upper()}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        priority = result.get('priority', {}).get('priority', 'unknown')
        priority_color = PRIORITY_COLORS.get(priority, "#6B7280")
        st.markdown(f"""
        <div class="glass-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 2rem;">⚡</div>
            <h3 style="margin: 0; color: #4b5563;">Priority</h3>
            <h2 style="margin: 0; font-size: 1.5rem; color: {priority_color}; animation: pulse 2s infinite;">
                {priority.upper()}
            </h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        confidence = result.get('confidence', {}).get('confidence_score', 0)
        st.markdown(f"""
        <div class="glass-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 2rem;">🎯</div>
            <h3 style="margin: 0; color: #4b5563;">Confidence</h3>
            <h2 style="margin: 0; font-size: 1.5rem; color: #10b981;">
                {confidence:.1%}
            </h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        risk_score = result.get('risk', {}).get('risk_score', 0)
        risk_color = "#ef4444" if risk_score > 0.7 else "#f59e0b" if risk_score > 0.3 else "#10b981"
        st.markdown(f"""
        <div class="glass-card" style="text-align: center; padding: 1rem;">
            <div style="font-size: 2rem;">⚠️</div>
            <h3 style="margin: 0; color: #4b5563;">Risk Score</h3>
            <h2 style="margin: 0; font-size: 1.5rem; color: {risk_color};">
                {risk_score:.2f}
            </h2>
        </div>
        """, unsafe_allow_html=True)


def render_classification_result(classification_data):
    """Render classification results with percentages in front."""
    st.markdown("### 📑 Classification Result")
    
    if not classification_data:
        st.info("No classification data available")
        return
    
    category = classification_data.get('category', 'unknown')
    confidence = classification_data.get('confidence', 0)
    
    col1, col2 = st.columns(2)
    with col1:
        st.metric("Category", category.upper())
    with col2:
        st.metric("Confidence", f"{confidence:.1%}")
    
    if 'top_categories' in classification_data:
        st.markdown("#### Top Predictions")
        top_cats = classification_data['top_categories']
        if isinstance(top_cats, dict):
            sorted_cats = sorted(top_cats.items(), key=lambda x: x[1], reverse=True)
            for cat, prob in sorted_cats[:5]:
                # Put percentage in front of the category name
                st.markdown(f"""
                <div style="display: flex; align-items: center; margin-bottom: 0.5rem;">
                    <span style="font-size: 1.2rem; font-weight: 600; color: #667eea; min-width: 60px;">{prob:.1%}</span>
                    <span style="margin-left: 1rem;">{cat}</span>
                </div>
                """, unsafe_allow_html=True)
                st.progress(prob, text="")
    
    if 'execution_time_ms' in classification_data:
        st.caption(f"⏱️ Execution time: {classification_data['execution_time_ms']:.1f}ms")


def render_priority_result(priority_data):
    """Render priority results with glowing effect."""
    st.markdown("### ⚡ Priority Assignment")
    
    if not priority_data:
        st.info("No priority data available")
        return
    
    priority = priority_data.get('priority', 'unknown')
    
    # Color code based on priority
    if priority.lower() == 'high':
        priority_color = "#ef4444"  # Red
        bg_color = "#a43434"
        glow_color = "#583333"
    elif priority.lower() == 'medium':
        priority_color = "#f59e0b"  # Orange/Yellow
        bg_color = "#B78329"
        glow_color = "#553333"
    else:  # low
        priority_color = "#10b981"  # Green
        bg_color = "#30af6d"
        glow_color = "#344343"
    
    # Glowing effect
    st.markdown(f"""
    <div style="
        text-align: center; 
        padding: 1.5rem; 
        background: linear-gradient(135deg, {bg_color}, white);
        border-radius: 12px; 
        margin-bottom: 1rem;
        box-shadow: 0 0 20px {glow_color}80;
        animation: glow 2s ease-in-out infinite;
    ">
        <h1 style="
            color: {priority_color}; 
            margin: 0; 
            font-size: 3rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            filter: drop-shadow(0 0 8px {glow_color}80);
        ">{priority.upper()}</h1>
    </div>
    
    
    """, unsafe_allow_html=True)
    
    if 'reasoning' in priority_data:
        st.info(f"**Reason:** {priority_data['reasoning']}")
    
    if 'execution_time_ms' in priority_data:
        st.caption(f"⏱️ Execution time: {priority_data['execution_time_ms']:.1f}ms")


def render_risk_analysis(risk_data):
    """Render risk analysis results with vertical breakdown."""
    st.markdown("### ⚠️ Risk Analysis")
    
    if not risk_data:
        st.info("No risk data available")
        return
    
    risk_score = risk_data.get('risk_score', 0)
    risk_color = "#f0bcbc" if risk_score > 0.7 else "#f0dcbb" if risk_score > 0.3 else "#beeddd"
    
    st.markdown(f"""
    <div style="text-align: center; padding: 1rem; background: {risk_color}20; border-radius: 8px; margin-bottom: 1rem;">
        <h2 style="color: {risk_color}; margin: 0;">Risk Score: {risk_score:.2f}</h2>
    </div>
    """, unsafe_allow_html=True)
    
    if 'components' in risk_data:
        st.markdown("#### Risk Breakdown")
        components = risk_data['components']
        if isinstance(components, dict):
            # Display each component on its own line
            category_base = components.get('category_base', 0)
            urgency = components.get('urgency', 0)
            sentiment = components.get('sentiment', 0)
            uncertainty = components.get('uncertainty', 0)
            
            # Vertical display with proper formatting
            st.markdown(f"""
            <div style="background: rgba(0,0,0,0.02); padding: 1rem; border-radius: 8px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                    <span style="font-weight: 600;">Category Base:</span>
                    <span style="color: #667eea;">{category_base:.2f}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                    <span style="font-weight: 600;">Urgency:</span>
                    <span style="color: #f59e0b;">{urgency:.2f}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                    <span style="font-weight: 600;">Sentiment:</span>
                    <span style="color: #10b981;">{sentiment:.2f}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                    <span style="font-weight: 600;">Uncertainty:</span>
                    <span style="color: #8b5cf6;">{uncertainty:.2f}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; padding-top: 0.5rem; border-top: 1px dashed #ccc;">
                    <span style="font-weight: 700;">Final Score:</span>
                    <span style="font-weight: 700; color: {risk_color};">{risk_score:.2f}</span>
                </div>
            </div>
            """, unsafe_allow_html=True)
    
    if 'execution_time_ms' in risk_data:
        st.caption(f"⏱️ Execution time: {risk_data['execution_time_ms']:.1f}ms")


def render_confidence_gauge(confidence_data):
    """Render confidence gauge with highlighted number."""
    st.markdown("### 🎯 Confidence Score")
    
    if not confidence_data:
        st.info("No confidence data available")
        return
    
    confidence = confidence_data.get('confidence_score', 0)
    threshold = 0.75
    
    # Create a gauge chart with highlighted number (fixed font properties)
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=confidence,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={
            'text': "Confidence", 
            'font': {'size': 20, 'color': "#b0a9de"}
        },
        number={
            'font': {'size': 40, 'color': "#0c18ed", 'family': 'Arial, sans-serif'},
           
            'valueformat': '.1%'
        },
        delta={
            'reference': threshold, 
            'position': "top", 
            'font': {'size': 16},
            'increasing': {'color': '#10b981'},
            'decreasing': {'color': '#ef4444'}
        },
        gauge={
            'axis': {
                'range': [0, 1], 
                'tickwidth': 2, 
                'tickcolor': "#333",
                'tickformat': '.0%',
                'dtick': 0.1
            },
            'bar': {'color': "#ed2c12", 'thickness': 0.3},
            'bgcolor': "#f0f2f6",
            'borderwidth': 0,
            'steps': [
                {'range': [0, threshold], 'color': "#fee2e2"},
                {'range': [threshold, 1], 'color': "#dcfce7"}
            ],
            'threshold': {
                'line': {'color': "#ef4444", 'width': 6},
                'thickness': 0.8,
                'value': threshold
            }
        }
    ))
    
    fig.update_layout(
        height=350, 
        margin=dict(l=30, r=30, t=60, b=30),
        paper_bgcolor="rgba(0,0,0,0)",
        font={'color': "#0a40f4", 'size': 20}
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    should_escalate = confidence_data.get('should_escalate', confidence < threshold)
    
    # Status with color
    if should_escalate:
        status_color = "#ef4444"
        status_text = "⚠️ Escalated"
        bg_color = "#5C61EA"
    else:
        status_color = "#10b981"
        status_text = "✅ Auto-approved"
        bg_color = "#576BF0"
    
    reasoning = confidence_data.get('reasoning', f"{'Low' if should_escalate else 'High'} confidence")
    
    st.markdown(f"""
    <div style="background: {bg_color}; padding: 1rem; border-radius: 8px; margin-top: 0.5rem; border-left: 4px solid {status_color};">
        <div style="display: flex; align-items: center;">
            <span style="font-size: 1.2rem; margin-right: 0.5rem;">{status_text.split()[0]}</span>
            <span style="font-weight: 600; color: {status_color};">{status_text}</span>
        </div>
        <div style="margin-top: 0.5rem; color: #4b5563;">{reasoning}</div>
    </div>
    """, unsafe_allow_html=True)
    
    if 'execution_time_ms' in confidence_data:
        st.caption(f"⏱️ Execution time: {confidence_data['execution_time_ms']:.1f}ms")


def render_state_timeline(history):
    """Render state machine timeline."""
    if not history:
        st.info("No state history available")
        return
    
    st.markdown("### 🔄 State Machine Timeline")
    
    expected_states = [
        ("IDLE", "TICKET_RECEIVED", "TICKET_SUBMITTED"),
        ("TICKET_RECEIVED", "VALIDATING_INPUT", "VALIDATION_PASSED"),
        ("VALIDATING_INPUT", "CLASSIFYING", "VALIDATION_PASSED"),
        ("CLASSIFYING", "RISK_SCORING", "CLASSIFICATION_COMPLETE"),
        ("RISK_SCORING", "PRIORITY_ASSIGNMENT", "RISK_CALCULATED"),
        ("PRIORITY_ASSIGNMENT", "CONFIDENCE_CHECK", "PRIORITY_ASSIGNED"),
        ("CONFIDENCE_CHECK", "ESCALATED", "ESCALATION_TRIGGERED"),
        ("ESCALATED", "COMPLETED", "PROCESSING_COMPLETE")
    ]
    
    transitions = []
    for i, (from_state, to_state, event) in enumerate(expected_states):
        transitions.append({
            'step': f"#{i+1}",
            'from': from_state,
            'to': to_state,
            'event': event,
            'pending': i >= len(history)
        })
    
    for trans in transitions:
        from_color = STATE_COLORS.get(trans['from'], '#6B7280')
        to_color = STATE_COLORS.get(trans['to'], '#6B7280')
        opacity = "0.5" if trans.get('pending', False) else "1"
        
        st.markdown(f"""
        <div style="display: flex; align-items: center; margin-bottom: 0.5rem; padding: 0.5rem; background: rgba(255,255,255,0.05); border-radius: 8px; opacity: {opacity};">
            <div style="width: 40px; font-weight: 600; color: #6b7280;">{trans['step']}</div>
            <div style="flex: 1; display: flex; align-items: center; justify-content: center;">
                <span style="background: {from_color}20; color: {from_color}; padding: 0.25rem 0.75rem; border-radius: 16px; font-weight: 600;">{trans['from']}</span>
                <span style="margin: 0 1rem; color: #6b7280;">{trans['event']}</span>
                <span style="background: {to_color}20; color: {to_color}; padding: 0.25rem 0.75rem; border-radius: 16px; font-weight: 600;">{trans['to']}</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    
    if len(history) < len(expected_states):
        st.caption("⚠️ Showing complete expected flow (dimmer = inferred states not in actual history)")


def render_tool_calls(tool_calls):
    """Render tool execution trace with tabs for each tool."""
    if not tool_calls:
        st.info("No tool calls were executed")
        return
    
    st.markdown("### 🔧 Tool Execution Trace")
    
    # Create tabs for each tool
    tool_names = [f"🔧 {t.get('tool_name', f'Tool {i+1}')}" for i, t in enumerate(tool_calls)]
    tabs = st.tabs(tool_names)
    
    for i, (tab, tool_call) in enumerate(zip(tabs, tool_calls)):
        with tab:
            tool_name = tool_call.get('tool_name', 'Unknown')
            exec_time = tool_call.get('execution_time_ms', 0)
            
            st.markdown(f"""
            <div style="margin-bottom: 1rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                    <strong style="font-size: 1.1rem;">{tool_name}</strong>
                    <span style="color: #6b7280; font-size: 0.8rem;">⏱️ {exec_time:.1f}ms</span>
                </div>
            """, unsafe_allow_html=True)
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**📥 Input:**")
                st.json(tool_call.get('input', {}))
            with col2:
                st.markdown("**📤 Output:**")
                st.json(tool_call.get('output', {}))
            
            if 'timestamp' in tool_call:
                st.caption(f"🕒 {tool_call['timestamp']}")


def render_metrics_dashboard(metrics):
    """Render metrics dashboard."""
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Classification Accuracy", f"{metrics.get('classification_accuracy', 0):.1%}")
    with col2:
        st.metric("Priority Accuracy", f"{metrics.get('priority_accuracy', 0):.1%}")
    with col3:
        st.metric("End-to-End Accuracy", f"{metrics.get('end_to_end_accuracy', 0):.1%}")


def render_decision_trace(decision_trace):
    """Render decision trace in a clean, structured format."""
    st.markdown("### 📋 Decision Trace")
    
    if not decision_trace:
        st.info("No decision trace available")
        return
    
    # Parse the decision trace if it's a string
    if isinstance(decision_trace, str):
        lines = decision_trace.strip().split('\n')
        
        # Create a styled container
        st.markdown("""
        <div class="glass-card" style="font-family: monospace; padding: 1.5rem;">
        """, unsafe_allow_html=True)
        
        for line in lines:
            line = line.strip()
            if not line:
                st.markdown("<br>", unsafe_allow_html=True)
            elif line.startswith("==="):
                # Header
                st.markdown(f"<span style='font-weight: 700; color: #1e293b;'>{line}</span>", unsafe_allow_html=True)
            elif line.startswith("---"):
                # Section header
                st.markdown(f"<span style='font-weight: 600; color: #4b5563;'>{line}</span>", unsafe_allow_html=True)
            elif ":" in line:
                # Key-value pair
                parts = line.split(":", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                
                # Special formatting for certain keys
                if key == "Run ID":
                    st.markdown(f"<span style='font-weight: 500;'>Run ID:</span> <span style='color: #2563eb;'>{value}</span>", unsafe_allow_html=True)
                elif key == "Status":
                    color = "#dc2626" if "escalated" in value.lower() else "#059669"
                    st.markdown(f"<span style='font-weight: 500;'>Status:</span> <span style='color: {color}; font-weight: 600;'>{value}</span>", unsafe_allow_html=True)
                elif key in ["Priority", "Confidence", "Risk Score"]:
                    st.markdown(f"<span style='font-weight: 500;'>{key}:</span> <span style='font-weight: 600;'>{value}</span>", unsafe_allow_html=True)
                elif key == "Breakdown":
                    st.markdown(f"<span style='font-weight: 500;'>Breakdown:</span> <span style='font-family: monospace;'>{value}</span>", unsafe_allow_html=True)
                elif key == "Reason":
                    st.markdown(f"<span style='font-weight: 500;'>Reason:</span> <span style='color: #dc2626;'>{value}</span>", unsafe_allow_html=True)
                elif key == "Execution Time":
                    st.markdown(f"<span style='font-weight: 500;'>Execution Time:</span> <span style='color: #6b7280;'>{value}</span>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<span style='font-weight: 500;'>{key}:</span> {value}", unsafe_allow_html=True)
            else:
                st.markdown(line, unsafe_allow_html=True)
        
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        # If it's not a string, just display it
        st.json(decision_trace)


def render_detailed_analysis(result):
    """Render the complete detailed analysis section."""
    with st.expander("🔍 View Detailed Analysis", expanded=True):
        # Create tabs for better organization
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📊 Classification", 
            "⚡ Priority & Risk", 
            "🔄 State Timeline", 
            "🔧 Tool Trace",
            "📝 Decision"
        ])
        
        with tab1:
            col1, col2 = st.columns(2)
            with col1:
                if result.get("classification"):
                    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                    st.markdown("#### 📑 Classification Result")
                    render_classification_result(result["classification"])
                    st.markdown('</div>', unsafe_allow_html=True)
            
            with col2:
                if result.get("confidence"):
                    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                    st.markdown("#### 🎯 Confidence Score")
                    render_confidence_gauge(result["confidence"])
                    st.markdown('</div>', unsafe_allow_html=True)
        
        with tab2:
            col1, col2 = st.columns(2)
            with col1:
                if result.get("priority"):
                    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                    st.markdown("#### ⚡ Priority Assignment")
                    render_priority_result(result["priority"])
                    st.markdown('</div>', unsafe_allow_html=True)
            
            with col2:
                if result.get("risk"):
                    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                    st.markdown("#### ⚠️ Risk Analysis")
                    render_risk_analysis(result["risk"])
                    st.markdown('</div>', unsafe_allow_html=True)
        
        with tab3:
            if result.get("state_history"):
                st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                render_state_timeline(result["state_history"])
                st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.info("No state history available")
        
        with tab4:
            if result.get("tool_calls"):
                st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                render_tool_calls(result["tool_calls"])
                st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.info("No tool calls were executed")
        
        with tab5:
            if result.get("decision_trace"):
                st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                render_decision_trace(result["decision_trace"])
                st.markdown('</div>', unsafe_allow_html=True)
            else:
                st.info("No decision trace available")
        
        # Escalation message if applicable
        if result.get("escalated", False):
            confidence_data = result.get("confidence", {})
            confidence = confidence_data.get("confidence_score", 0)
            threshold = 0.75
            reasoning = confidence_data.get("reasoning", f"Low confidence ({confidence:.1%}) below threshold ({threshold:.1%})")
            
            st.markdown(f"""
            <div class="glass-card" style="background: #fee2e2; border-left: 4px solid #ef4444; margin-top: 1rem;">
                <div style="display: flex; align-items: center;">
                    <span style="font-size: 1.5rem; margin-right: 1rem;">⚠️</span>
                    <div>
                        <strong style="color: #ef4444; font-size: 1.1rem;">Escalation Recommended</strong>
                        <p style="margin: 0; color: #4b5563;">{reasoning}</p>
                    </div>
                </div>
                <div style="text-align: right; color: #6b7280; font-size: 0.8rem; margin-top: 0.5rem;">
                    Execution time: {result.get('execution_time_ms', 0):.1f}ms
                </div>
            </div>
            """, unsafe_allow_html=True)
