"""UI Theme and styling definitions."""

# -------------------------------------------------------------------
# COLOR PALETTE
# -------------------------------------------------------------------

COLOR_PRIMARY = "#6366F1"   # Indigo
COLOR_SUCCESS = "#10B981"   # Emerald
COLOR_WARNING = "#F59E0B"   # Amber
COLOR_DANGER = "#EF4444"    # Red
COLOR_INFO = "#3B82F6"      # Blue
COLOR_DARK = "#1F2937"      # Dark Gray
COLOR_LIGHT = "#F3F4F6"     # Light Gray
COLOR_BORDER = "#E5E7EB"    # Border Gray


# -------------------------------------------------------------------
# STATE COLORS
# -------------------------------------------------------------------

STATE_COLORS = {
    "IDLE": "#6B7280",
    "TICKET_RECEIVED": "#3B82F6",
    "VALIDATING_INPUT": "#8B5CF6",
    "CLASSIFYING": "#8B5CF6",
    "RISK_SCORING": "#EC4899",
    "PRIORITY_ASSIGNMENT": "#EC4899",
    "CONFIDENCE_CHECK": "#F59E0B",
    "ESCALATED": "#EF4444",
    "COMPLETED": "#10B981",
    "NEED_MORE_INFO": "#F59E0B",
    "ERROR": "#EF4444",
}


# -------------------------------------------------------------------
# PRIORITY COLORS
# -------------------------------------------------------------------

PRIORITY_COLORS = {
    "low": COLOR_SUCCESS,
    "medium": COLOR_WARNING,
    "high": COLOR_DANGER,
}


# -------------------------------------------------------------------
# CUSTOM CSS
# -------------------------------------------------------------------

CUSTOM_CSS = """
<style>

/* =========================================================
GLOBAL LAYOUT
========================================================= */

.block-container {
    padding-top: 1.5rem;
    padding-bottom: 2rem;
    max-width: 1200px;
}

/* Typography */

h1 {
    font-weight: 700;
    letter-spacing: -0.4px;
}

h2 {
    font-weight: 600;
    margin-top: 1.5rem;
}

h3 {
    font-weight: 600;
}

section.main > div {
    padding-top: 0.5rem;
}


/* =========================================================
LIGHT THEME
========================================================= */

.light-theme .stApp {
    background-color: #FFFFFF;
    color: #111827;
}

.light-theme h1,
.light-theme h2,
.light-theme h3 {
    color: #111827;
}

/* Cards */

.light-theme .card {
    background: rgba(255,255,255,0.9);
    border: 1px solid #E5E7EB;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 3px 6px rgba(0,0,0,0.05);
}

.light-theme .card:hover {
    box-shadow: 0 6px 10px rgba(0,0,0,0.08);
}

/* Metrics */

.light-theme [data-testid="stMetric"] {
    background: #FAFAFA;
    border: 1px solid #EEE;
    border-radius: 8px;
    padding: 12px;
    color: #111827;
}

.light-theme [data-testid="stMetricValue"] {
    color: #111827;
}

/* Inputs */

.light-theme input,
.light-theme textarea {
    color: #111827 !important;
}


/* =========================================================
DARK THEME
========================================================= */

.dark-theme .stApp {
    background-color: #0E1117;
    color: #E5E7EB;
}

.dark-theme h1,
.dark-theme h2,
.dark-theme h3 {
    color: #F9FAFB;
}

/* Cards */

.dark-theme .card {
    background: rgba(30,30,46,0.7);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 10px;
    padding: 20px;
}

.dark-theme .card:hover {
    box-shadow: 0 6px 10px rgba(0,0,0,0.35);
}

/* Metrics */

.dark-theme [data-testid="stMetric"] {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 8px;
    padding: 12px;
    color: #F9FAFB;
}

.dark-theme [data-testid="stMetricValue"] {
    color: #F9FAFB;
}

/* Inputs */

.dark-theme input,
.dark-theme textarea {
    background: #1F2937;
    color: #F9FAFB !important;
}


/* =========================================================
BUTTONS
========================================================= */

.stButton > button {
    border-radius: 6px;
    padding: 8px 18px;
    font-weight: 600;
    border: none;
    transition: background 0.15s ease;
}

.stButton > button:hover {
    transform: none;
    box-shadow: none;
}


/* =========================================================
STATE TIMELINE
========================================================= */

.state-timeline {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.state-item {
    display: flex;
    gap: 12px;
    padding: 12px 14px;
    border-left: 3px solid #6366F1;
    border-radius: 6px;
    transition: background 0.15s ease;
}

.light-theme .state-item {
    background: #FAFAFA;
}

.dark-theme .state-item {
    background: rgba(255,255,255,0.03);
}

.state-item.active {
    border-left-color: #10B981;
}

.light-theme .state-item.active {
    background: rgba(99,102,241,0.08);
}

.dark-theme .state-item.active {
    background: rgba(99,102,241,0.18);
}


/* =========================================================
BADGES
========================================================= */

.badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.badge-success {
    background: #D1FAE5;
    color: #065F46;
}

.badge-warning {
    background: #FEF3C7;
    color: #78350F;
}

.badge-danger {
    background: #FEE2E2;
    color: #7F1D1D;
}


/* =========================================================
PROGRESS BAR
========================================================= */

.progress-bar {
    height: 8px;
    background: #E5E7EB;
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg,#6366F1,#8B5CF6);
}


/* =========================================================
EXPANDERS
========================================================= */

.streamlit-expanderHeader {
    font-weight: 600;
}

.streamlit-expanderContent {
    padding-top: 6px;
}


/* =========================================================
ANIMATIONS
========================================================= */

@keyframes pulse {
    0%,100% {opacity:1;}
    50% {opacity:0.85;}
}

@keyframes fadeIn {
    from {opacity:0; transform: translateY(6px);}
    to {opacity:1; transform: translateY(0);}
}

.fadeIn {
    animation: fadeIn 0.25s ease-out;
}

.pulse {
    animation: pulse 2.5s ease-in-out infinite;
}


/* =========================================================
SPINNER
========================================================= */

@keyframes spin {
    to { transform: rotate(360deg); }
}

.spinner {
    display: inline-block;
    width: 18px;
    height: 18px;
    border: 3px solid rgba(99,102,241,0.2);
    border-top: 3px solid #6366F1;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}


/* =========================================================
SIDEBAR
========================================================= */

section[data-testid="stSidebar"] {
    border-right: 1px solid #E5E7EB;
}

</style>
"""

# -------------------------------------------------------------------
# BADGE UTILITIES
# -------------------------------------------------------------------

def get_state_badge(state: str) -> str:
    """Get HTML badge for state."""
    color = STATE_COLORS.get(state, "#6B7280")
    return (
        f'<div style="display:inline-block;'
        f'background:{color};color:white;'
        f'padding:5px 10px;border-radius:14px;'
        f'font-weight:600;font-size:11px;">{state}</div>'
    )


def get_priority_badge(priority: str) -> str:
    """Get HTML badge for priority."""
    color = PRIORITY_COLORS.get(priority, "#6B7280")
    labels = {"low": "Low", "medium": "Medium", "high": "High"}
    label = labels.get(priority, priority.upper())

    return (
        f'<div style="display:inline-block;'
        f'background:{color};color:white;'
        f'padding:5px 10px;border-radius:14px;'
        f'font-weight:600;font-size:11px;">{label}</div>'
    )


def get_confidence_color(confidence: float) -> str:
    """Get color based on confidence level."""
    if confidence >= 0.8:
        return COLOR_SUCCESS
    elif confidence >= 0.6:
        return COLOR_WARNING
    else:
        return COLOR_DANGER