
"""
Train the ML model for Intelligent Ticket Triage Agent
"""

import pandas as pd
import numpy as np
import pickle
import re
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from collections import Counter

# Configuration
RANDOM_SEED = 42
TEST_SIZE = 0.2
MAX_FEATURES = 5000

# Paths
MODEL_PATH = Path("models/model.pkl")
VECTORIZER_PATH = Path("models/vectorizer.pkl")
MODEL_PATH.parent.mkdir(exist_ok=True)

def clean_text(text):
    """Clean and preprocess text"""
    if pd.isna(text) or not isinstance(text, str):
        return ""
    text = str(text).lower()
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"[^a-zA-Z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_csv_data():
    """Load data from CSV file"""
    csv_path = input("\n📁 Enter path to your CSV file (or press Enter for built-in data): ").strip()
    
    if not csv_path:
        return None
    
    if not Path(csv_path).exists():
        print(f"❌ File not found: {csv_path}")
        return None
    
    print(f"\n📂 Loading: {csv_path}")
    df = pd.read_csv(csv_path)
    print(f"📊 Loaded {len(df)} rows")
    print(f"\nColumns: {list(df.columns)}")
    
    # Ask user to identify columns
    print("\n🔍 Please identify the columns:")
    
    # Text column
    print("\nWhich column contains the ticket description/text?")
    for i, col in enumerate(df.columns, 1):
        print(f"{i}. {col}")
    text_choice = int(input("Enter column number: ")) - 1
    text_col = df.columns[text_choice]
    
    # Category column
    print("\nWhich column contains the category/type?")
    for i, col in enumerate(df.columns, 1):
        print(f"{i}. {col}")
    cat_choice = int(input("Enter column number: ")) - 1
    category_col = df.columns[cat_choice]
    
    print(f"\n✅ Using:")
    print(f"   Text: '{text_col}'")
    print(f"   Category: '{category_col}'")
    
    # Extract data
    texts = df[text_col].fillna("").astype(str).apply(clean_text).tolist()
    categories = df[category_col].fillna("").astype(str).tolist()
    
    # Filter empty
    valid_data = [(t, c) for t, c in zip(texts, categories) if t and len(t) > 5]
    print(f"\n📊 Valid samples: {len(valid_data)}")
    
    return valid_data

def create_sample_data():
    """Create sample training data"""
    return [
        # Billing
        ("I was charged twice for my subscription", "Billing"),
        ("Please refund the duplicate payment", "Billing"),
        ("My invoice shows wrong amount", "Billing"),
        ("Can't update my payment method", "Billing"),
        ("When will I get my money back", "Billing"),
        
        # Technical
        ("The application crashes when I try to login", "Technical"),
        ("Database connection error occurred", "Technical"),
        ("Server is down, cannot access the system", "Technical"),
        ("API returns 500 error", "Technical"),
        ("Page loads very slowly", "Technical"),
        
        # Account
        ("I forgot my password", "Account"),
        ("Can't login to my account", "Account"),
        ("Someone hacked my account", "Account"),
        ("How to change my email", "Account"),
        ("Account locked after multiple attempts", "Account"),
        
        # Delivery
        ("My package hasn't arrived", "Delivery"),
        ("Where is my order", "Delivery"),
        ("Shipping was delayed", "Delivery"),
        ("Wrong item delivered", "Delivery"),
        ("Tracking number not working", "Delivery"),
        
        # General
        ("How does this work", "General"),
        ("Need help with your service", "General"),
        ("What are your business hours", "General"),
        ("Contact support please", "General"),
        ("Thanks for your help", "General"),
    ]

def main():
    print("="*60)
    print("TICKET TRIAGE MODEL TRAINING")
    print("="*60)
    
    # Try to load CSV data
    csv_data = load_csv_data()
    
    # Get sample data
    sample_data = create_sample_data()
    
    # Combine data
    if csv_data:
        all_data = csv_data + sample_data
        print(f"\n📊 Total samples: {len(all_data)} (CSV: {len(csv_data)} + Sample: {len(sample_data)})")
    else:
        all_data = sample_data
        print(f"\n📊 Using sample data only: {len(all_data)} samples")
    
    # Prepare data
    texts = [item[0] for item in all_data]
    labels = [item[1] for item in all_data]
    
    # Show distribution
    dist = Counter(labels)
    print("\n📈 Category Distribution:")
    for cat, count in sorted(dist.items()):
        print(f"   {cat}: {count}")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=TEST_SIZE, random_state=RANDOM_SEED
    )
    
    print(f"\n📊 Training: {len(X_train)} samples")
    print(f"📊 Testing: {len(X_test)} samples")
    
    # Create vectorizer
    print("\n🔄 Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        max_features=MAX_FEATURES,
        stop_words='english',
        lowercase=True
    )
    
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    # Train classifier
    print("🔄 Training Logistic Regression...")
    classifier = LogisticRegression(
        max_iter=1000,
        random_state=RANDOM_SEED,
        multi_class='multinomial'
    )
    
    classifier.fit(X_train_vec, y_train)
    
    # Evaluate
    accuracy = classifier.score(X_test_vec, y_test)
    print(f"\n✅ Test Accuracy: {accuracy:.2%}")
    
    # Save model
    print("\n💾 Saving model...")
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(classifier, f)
    
    with open(VECTORIZER_PATH, 'wb') as f:
        pickle.dump(vectorizer, f)
    
    print(f"✅ Model saved to: {MODEL_PATH}")
    print(f"✅ Vectorizer saved to: {VECTORIZER_PATH}")
    
    # Test
    print("\n" + "="*60)
    print("TESTING MODEL")
    print("="*60)
    
    test_queries = [
        "I was charged twice",
        "The app crashes",
        "I forgot my password",
        "Where is my package?",
        "How does this work?",
    ]
    
    for query in test_queries:
        cleaned = clean_text(query)
        X_test = vectorizer.transform([cleaned])
        pred = classifier.predict(X_test)[0]
        proba = classifier.predict_proba(X_test).max()
        print(f"\n📝 {query}")
        print(f"   → {pred} ({proba:.2%})")
    
    print("\n✅ Training complete! Run: streamlit run app.py")

if __name__ == "__main__":
    main()
