"""Metrics tracking and computation."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from collections import Counter
import json


@dataclass
class Metrics:
    """Metrics for evaluation."""
    
    total_runs: int = 0
    total_correct_classifications: int = 0
    total_correct_priorities: int = 0
    total_end_to_end_correct: int = 0
    total_escalations: int = 0
    
    # By category metrics
    by_category: Dict[str, dict] = field(default_factory=dict)
    
    # Confidence distribution
    confidence_scores: List[float] = field(default_factory=list)
    
    # Confusion matrix
    confusion_matrix: Dict[str, Dict[str, int]] = field(default_factory=dict)
    
    def record_result(
        self,
        predicted_category: str,
        true_category: str,
        predicted_priority: str,
        true_priority: str,
        confidence: float,
        escalated: bool,
    ):
        """Record a single result."""
        self.total_runs += 1
        
        # Classification accuracy
        if predicted_category == true_category:
            self.total_correct_classifications += 1
        
        # Priority accuracy
        if predicted_priority == true_priority:
            self.total_correct_priorities += 1
        
        # End-to-end accuracy
        if predicted_category == true_category and predicted_priority == true_priority:
            self.total_end_to_end_correct += 1
        
        # Escalation
        if escalated:
            self.total_escalations += 1
        
        # Confidence distribution
        self.confidence_scores.append(confidence)
        
        # Confusion matrix
        if true_category not in self.confusion_matrix:
            self.confusion_matrix[true_category] = {}
        
        if predicted_category not in self.confusion_matrix[true_category]:
            self.confusion_matrix[true_category][predicted_category] = 0
        
        self.confusion_matrix[true_category][predicted_category] += 1
        
        # By-category metrics
        if true_category not in self.by_category:
            self.by_category[true_category] = {
                "total": 0,
                "correct": 0,
                "precision_total": 0,
                "precision_correct": 0,
            }
        
        self.by_category[true_category]["total"] += 1
        
        if predicted_category == true_category:
            self.by_category[true_category]["correct"] += 1
        
        if predicted_category not in self.by_category:
            self.by_category[predicted_category] = {
                "total": 0,
                "correct": 0,
                "precision_total": 0,
                "precision_correct": 0,
            }
        
        self.by_category[predicted_category]["precision_total"] += 1
        
        if predicted_category == true_category:
            self.by_category[predicted_category]["precision_correct"] += 1
    
    def get_classification_accuracy(self) -> float:
        """Get classification accuracy."""
        if self.total_runs == 0:
            return 0.0
        return self.total_correct_classifications / self.total_runs
    
    def get_priority_accuracy(self) -> float:
        """Get priority assignment accuracy."""
        if self.total_runs == 0:
            return 0.0
        return self.total_correct_priorities / self.total_runs
    
    def get_end_to_end_accuracy(self) -> float:
        """Get end-to-end accuracy (classification + priority)."""
        if self.total_runs == 0:
            return 0.0
        return self.total_end_to_end_correct / self.total_runs
    
    def get_escalation_rate(self) -> float:
        """Get escalation rate."""
        if self.total_runs == 0:
            return 0.0
        return self.total_escalations / self.total_runs
    
    def get_average_confidence(self) -> float:
        """Get average confidence."""
        if not self.confidence_scores:
            return 0.0
        return sum(self.confidence_scores) / len(self.confidence_scores)
    
    def get_confidence_distribution(self):
        """Get confidence distribution for visualization."""
        if not self.confidence_scores:
            return {}
        
        # Group into bins
        bins = {
            "0-20%": 0,
            "20-40%": 0,
            "40-60%": 0,
            "60-80%": 0,
            "80-100%": 0,
        }
        
        for conf in self.confidence_scores:
            conf_pct = conf * 100
            if conf_pct < 20:
                bins["0-20%"] += 1
            elif conf_pct < 40:
                bins["20-40%"] += 1
            elif conf_pct < 60:
                bins["40-60%"] += 1
            elif conf_pct < 80:
                bins["60-80%"] += 1
            else:
                bins["80-100%"] += 1
        
        return bins
    
    def get_by_category_accuracy(self, category: str) -> Optional[float]:
        """Get accuracy for specific category."""
        if category not in self.by_category:
            return None
        
        stats = self.by_category[category]
        if stats["total"] == 0:
            return None
        
        return stats["correct"] / stats["total"]
    
    def to_dict(self):
        """Convert metrics to dictionary."""
        return {
            "total_runs": self.total_runs,
            "classification_accuracy": self.get_classification_accuracy(),
            "priority_accuracy": self.get_priority_accuracy(),
            "end_to_end_accuracy": self.get_end_to_end_accuracy(),
            "escalation_rate": self.get_escalation_rate(),
            "average_confidence": self.get_average_confidence(),
            "confidence_distribution": self.get_confidence_distribution(),
            "by_category": self.by_category,
        }
    
    def to_json(self, indent=2) -> str:
        """Convert metrics to JSON."""
        return json.dumps(self.to_dict(), indent=indent)
