"""Structured tool layer with Pydantic models."""

from pydantic import BaseModel, Field
from typing import Dict, Any
from enum import Enum
from datetime import datetime


class Category(str, Enum):
    """Ticket categories."""

    BUG = "bug"
    FEATURE_REQUEST = "feature_request"
    DOCUMENTATION = "documentation"
    INFRASTRUCTURE = "infrastructure"
    SECURITY = "security"
    PERFORMANCE = "performance"
    UNCLEAR = "unclear"


class Priority(str, Enum):
    """Priority levels."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


# ============================================================================
# TOOL INPUT/OUTPUT MODELS
# ============================================================================


class ClassifyTicketInput(BaseModel):
    """Input for classify_ticket tool."""

    subject: str = Field(..., min_length=3, max_length=200)
    description: str = Field(..., min_length=10, max_length=5000)


class ClassifyTicketOutput(BaseModel):
    """Output from classify_ticket tool."""

    category: Category
    confidence: float = Field(..., ge=0.0, le=1.0)
    top_categories: Dict[str, float]
    execution_time_ms: float


class ComputeRiskScoreInput(BaseModel):
    """Input for compute_risk_score tool."""

    category: Category
    urgency_keywords: list = Field(default_factory=list)
    description: str
    sentiment_score: float = Field(default=0.0, ge=-1.0, le=1.0)


class ComputeRiskScoreOutput(BaseModel):
    """Output from compute_risk_score tool."""

    risk_score: float = Field(..., ge=0.0, le=1.0)
    components: Dict[str, float]
    breakdown: str
    execution_time_ms: float


class AssignPriorityInput(BaseModel):
    """Input for assign_priority tool."""

    risk_score: float = Field(..., ge=0.0, le=1.0)
    category: Category


class AssignPriorityOutput(BaseModel):
    """Output from assign_priority tool."""

    priority: Priority
    reasoning: str
    execution_time_ms: float


class CheckConfidenceInput(BaseModel):
    """Input for check_confidence tool."""

    classification_confidence: float = Field(..., ge=0.0, le=1.0)
    risk_score: float = Field(..., ge=0.0, le=1.0)
    threshold: float = Field(default=0.75, ge=0.0, le=1.0)


class CheckConfidenceOutput(BaseModel):
    """Output from check_confidence tool."""

    should_escalate: bool
    confidence_score: float = Field(..., ge=0.0, le=1.0)
    reasoning: str
    execution_time_ms: float


class LogEventInput(BaseModel):
    """Input for log_event tool."""

    run_id: str
    event_type: str
    data: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.now)


class LogEventOutput(BaseModel):
    """Output from log_event tool."""

    success: bool
    log_id: str
    execution_time_ms: float


# ============================================================================
# TOOL CALL RECORD
# ============================================================================


class ToolCall:
    """Record of a tool call with input/output."""

    def __init__(
        self,
        tool_name: str,
        input_model: BaseModel,
        output_model: BaseModel,
        execution_time_ms: float,
    ):
        self.tool_name = tool_name
        self.input_data = input_model.model_dump(exclude_none=True)
        self.output_data = output_model.model_dump(exclude_none=True)
        self.execution_time_ms = execution_time_ms
        self.timestamp = datetime.now()

    def to_dict(self):
        """Convert to dictionary."""
        return {
            "tool_name": self.tool_name,
            "input": self.input_data,
            "output": self.output_data,
            "execution_time_ms": self.execution_time_ms,
            "timestamp": self.timestamp.isoformat(),
        }