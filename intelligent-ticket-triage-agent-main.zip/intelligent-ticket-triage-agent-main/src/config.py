"""Configuration management for the ticket triage system."""

import json
from pathlib import Path
from dataclasses import dataclass


@dataclass
class TriageConfig:
    """Configuration for the triage agent."""
    
    confidence_threshold: float = 0.75
    max_steps: int = 20
    seed: int = 42
    risk_weights: dict = None
    
    def __post_init__(self):
        if self.risk_weights is None:
            self.risk_weights = {
                "category_base": 0.3,
                "urgency_keyword": 0.25,
                "sentiment_negativity": 0.25,
                "uncertainty": 0.2,
            }
    
    @classmethod
    def from_file(cls, config_path: str = None):
        """Load configuration from JSON file."""
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config.json"
        
        if Path(config_path).exists():
            with open(config_path) as f:
                data = json.load(f)
            return cls(**data)
        return cls()
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "confidence_threshold": self.confidence_threshold,
            "max_steps": self.max_steps,
            "seed": self.seed,
            "risk_weights": self.risk_weights,
        }


# Global config instance
_config = None


def get_config() -> TriageConfig:
    """Get global config instance."""
    global _config
    if _config is None:
        _config = TriageConfig.from_file()
    return _config


def set_config(config: TriageConfig):
    """Set global config instance."""
    global _config
    _config = config
