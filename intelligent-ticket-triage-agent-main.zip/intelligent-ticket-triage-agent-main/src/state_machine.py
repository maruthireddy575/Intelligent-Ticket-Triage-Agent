"""Explicit deterministic state machine for ticket triage."""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List
from datetime import datetime
import uuid


class TriageState(str, Enum):
    """All possible states in the triage workflow."""
    
    IDLE = "IDLE"
    TICKET_RECEIVED = "TICKET_RECEIVED"
    VALIDATING_INPUT = "VALIDATING_INPUT"
    CLASSIFYING = "CLASSIFYING"
    RISK_SCORING = "RISK_SCORING"
    PRIORITY_ASSIGNMENT = "PRIORITY_ASSIGNMENT"
    CONFIDENCE_CHECK = "CONFIDENCE_CHECK"
    ESCALATED = "ESCALATED"
    COMPLETED = "COMPLETED"
    NEED_MORE_INFO = "NEED_MORE_INFO"
    ERROR = "ERROR"


class TriageEvent(str, Enum):
    """Events that trigger state transitions."""
    
    TICKET_SUBMITTED = "TICKET_SUBMITTED"
    VALIDATION_PASSED = "VALIDATION_PASSED"
    VALIDATION_FAILED = "VALIDATION_FAILED"
    CLASSIFICATION_COMPLETE = "CLASSIFICATION_COMPLETE"
    RISK_CALCULATED = "RISK_CALCULATED"
    PRIORITY_ASSIGNED = "PRIORITY_ASSIGNED"
    CONFIDENCE_HIGH = "CONFIDENCE_HIGH"
    CONFIDENCE_LOW = "CONFIDENCE_LOW"
    ESCALATION_TRIGGERED = "ESCALATION_TRIGGERED"
    PROCESSING_COMPLETE = "PROCESSING_COMPLETE"
    ERROR_OCCURRED = "ERROR_OCCURRED"


# State transition rules (explicit FSM)
STATE_TRANSITIONS = {
    TriageState.IDLE: [
        (TriageEvent.TICKET_SUBMITTED, TriageState.TICKET_RECEIVED),
    ],
    TriageState.TICKET_RECEIVED: [
        (TriageEvent.VALIDATION_PASSED, TriageState.VALIDATING_INPUT),
        (TriageEvent.VALIDATION_FAILED, TriageState.NEED_MORE_INFO),
        (TriageEvent.ERROR_OCCURRED, TriageState.ERROR),
    ],
    TriageState.VALIDATING_INPUT: [
        (TriageEvent.VALIDATION_PASSED, TriageState.CLASSIFYING),
        (TriageEvent.VALIDATION_FAILED, TriageState.NEED_MORE_INFO),
    ],
    TriageState.CLASSIFYING: [
        (TriageEvent.CLASSIFICATION_COMPLETE, TriageState.RISK_SCORING),
        (TriageEvent.ERROR_OCCURRED, TriageState.ERROR),
    ],
    TriageState.RISK_SCORING: [
        (TriageEvent.RISK_CALCULATED, TriageState.PRIORITY_ASSIGNMENT),
        (TriageEvent.ERROR_OCCURRED, TriageState.ERROR),
    ],
    TriageState.PRIORITY_ASSIGNMENT: [
        (TriageEvent.PRIORITY_ASSIGNED, TriageState.CONFIDENCE_CHECK),
        (TriageEvent.ERROR_OCCURRED, TriageState.ERROR),
    ],
    TriageState.CONFIDENCE_CHECK: [
        (TriageEvent.CONFIDENCE_HIGH, TriageState.COMPLETED),
        (TriageEvent.CONFIDENCE_LOW, TriageState.ESCALATED),
        (TriageEvent.ESCALATION_TRIGGERED, TriageState.ESCALATED),
    ],
    TriageState.ESCALATED: [
        (TriageEvent.PROCESSING_COMPLETE, TriageState.COMPLETED),
    ],
    TriageState.COMPLETED: [],
    TriageState.NEED_MORE_INFO: [],
    TriageState.ERROR: [],
}


@dataclass
class StateTransition:
    """Record of a state transition."""
    
    run_id: str
    previous_state: TriageState
    event: TriageEvent
    next_state: TriageState
    timestamp: datetime
    metadata: dict = field(default_factory=dict)
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "run_id": self.run_id,
            "previous_state": self.previous_state.value,
            "event": self.event.value,
            "next_state": self.next_state.value,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


class StateMachine:
    """Explicit deterministic state machine for ticket triage."""
    
    def __init__(self, run_id: str = None):
        self.run_id = run_id or str(uuid.uuid4())
        self.current_state = TriageState.IDLE
        self.transitions: List[StateTransition] = []
    
    def can_transition(self, event: TriageEvent) -> bool:
        """Check if transition is allowed from current state."""
        allowed_transitions = STATE_TRANSITIONS.get(self.current_state, [])
        return any(e == event for e, _ in allowed_transitions)
    
    def get_next_state(self, event: TriageEvent) -> Optional[TriageState]:
        """Get next state for given event, or None if not allowed."""
        allowed_transitions = STATE_TRANSITIONS.get(self.current_state, [])
        for e, next_state in allowed_transitions:
            if e == event:
                return next_state
        return None
    
    def transition(self, event: TriageEvent, metadata: dict = None) -> bool:
        """Attempt state transition."""
        if not self.can_transition(event):
            return False
        
        next_state = self.get_next_state(event)
        if next_state is None:
            return False
        
        transition = StateTransition(
            run_id=self.run_id,
            previous_state=self.current_state,
            event=event,
            next_state=next_state,
            timestamp=datetime.now(),
            metadata=metadata or {},
        )
        
        self.transitions.append(transition)
        self.current_state = next_state
        return True
    
    def get_history(self) -> List[StateTransition]:
        """Get transition history."""
        return self.transitions.copy()
    
    def reset(self):
        """Reset to idle state."""
        self.current_state = TriageState.IDLE
        self.transitions.clear()
    
    def __repr__(self):
        return f"StateMachine(run_id={self.run_id}, state={self.current_state.value}, transitions={len(self.transitions)})"
