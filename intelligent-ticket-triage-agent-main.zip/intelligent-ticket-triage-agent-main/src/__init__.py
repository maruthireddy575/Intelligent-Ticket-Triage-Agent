"""Intelligent Ticket Triage Agent - Core Package"""

__version__ = "1.0.0"
__author__ = "Engineering Team"
__description__ = "Production-grade intelligent ticket triage system"
