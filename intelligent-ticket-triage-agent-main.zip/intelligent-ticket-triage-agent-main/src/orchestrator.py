
"""Main triage orchestrator that combines all components."""

import time
from typing import Optional, Dict, Any, List

from src.state_machine import StateMachine, TriageEvent
from src.tools import (
    Category,
    Priority,
    ClassifyTicketInput,
    ClassifyTicketOutput,
    ComputeRiskScoreInput,
    ComputeRiskScoreOutput,
    AssignPriorityInput,
    AssignPriorityOutput,
    CheckConfidenceInput,
    CheckConfidenceOutput,
    ToolCall,
)

from src.ml_model import get_model
from src.risk_engine import RiskEngine
from src.confidence import ConfidenceEngine
from src.logger import TriageLogger
from src.config import get_config


class TriageOrchestrator:
    """Main orchestrator for ticket triage workflow."""

    def __init__(self):

        self.config = get_config()
        self.logger = TriageLogger()

        self.model = get_model()
        self.risk_engine = RiskEngine()
        self.confidence_engine = ConfidenceEngine()

        self.state_machine: Optional[StateMachine] = None
        self.tool_calls: List[ToolCall] = []
        self.start_time: Optional[float] = None

    def process_ticket(
        self,
        subject: str,
        description: str,
        escalation_override: bool = False,
    ) -> Dict[str, Any]:

        self.start_time = time.time()

        self.state_machine = StateMachine()
        self.tool_calls = []

        result = {
            "run_id": self.state_machine.run_id,
            "status": "processing",
            "error": None,
            "classification": None,
            "risk": None,
            "priority": None,
            "confidence": None,
            "escalated": False,
            "state_history": [],
            "tool_calls": [],
            "decision_trace": "",
            "execution_time_ms": 0,
        }

        try:
            # Initial state is already logged by StateMachine init
            self._log_current_state()

            # STATE 1: TICKET RECEIVED
            self._transition(TriageEvent.TICKET_SUBMITTED)
            self._log_current_state()

            # Validate input
            if not self._validate_input(subject, description):
                self._transition(TriageEvent.VALIDATION_FAILED)
                self._log_current_state()
                result["status"] = "validation_failed"
                result["error"] = "Invalid ticket input"
                return result

            self._transition(TriageEvent.VALIDATION_PASSED)
            self._log_current_state()

            # STATE 2: VALIDATING_INPUT -> CLASSIFYING
            self._transition(TriageEvent.VALIDATION_PASSED)  # This moves to CLASSIFYING
            self._log_current_state()

            # CLASSIFICATION
            classification = self._classify_ticket(subject, description)

            if not classification:
                return self._error_result(result, "Classification failed")

            result["classification"] = classification
            self._transition(TriageEvent.CLASSIFICATION_COMPLETE)
            self._log_current_state()

            # STATE 3: CLASSIFYING -> RISK_SCORING
            self._transition(TriageEvent.CLASSIFICATION_COMPLETE)  # This moves to RISK_SCORING
            self._log_current_state()

            # RISK
            risk = self._compute_risk_score(subject, description, classification)

            if not risk:
                return self._error_result(result, "Risk scoring failed")

            result["risk"] = risk
            self._transition(TriageEvent.RISK_CALCULATED)
            self._log_current_state()

            # STATE 4: RISK_SCORING -> PRIORITY_ASSIGNMENT
            self._transition(TriageEvent.RISK_CALCULATED)  # This moves to PRIORITY_ASSIGNMENT
            self._log_current_state()

            # PRIORITY
            priority = self._assign_priority(
                classification["category"], risk["risk_score"]
            )

            if not priority:
                return self._error_result(result, "Priority assignment failed")

            result["priority"] = priority
            self._transition(TriageEvent.PRIORITY_ASSIGNED)
            self._log_current_state()

            # STATE 5: PRIORITY_ASSIGNMENT -> CONFIDENCE_CHECK
            self._transition(TriageEvent.PRIORITY_ASSIGNED)  # This moves to CONFIDENCE_CHECK
            self._log_current_state()

            # CONFIDENCE
            confidence = self._check_confidence(
                classification["confidence"],
                risk["risk_score"],
                escalation_override,
            )

            if not confidence:
                return self._error_result(result, "Confidence check failed")

            result["confidence"] = confidence

            if confidence["should_escalate"]:
                result["escalated"] = True
                result["status"] = "escalated"
                self._transition(TriageEvent.ESCALATION_TRIGGERED)
                self._log_current_state()
                
                # STATE 6: CONFIDENCE_CHECK -> ESCALATED
                self._transition(TriageEvent.ESCALATION_TRIGGERED)  # This moves to ESCALATED
                self._log_current_state()
            else:
                result["status"] = "completed"
                self._transition(TriageEvent.CONFIDENCE_HIGH)
                self._log_current_state()

            # STATE 7: ESCALATED -> COMPLETED or CONFIDENCE_CHECK -> COMPLETED
            self._transition(TriageEvent.PROCESSING_COMPLETE)
            self._log_current_state()

            # STATE HISTORY - Get full history from state machine
            result["state_history"] = [
                t.to_dict() for t in self.state_machine.get_history()
            ]

            # TOOL CALLS
            result["tool_calls"] = [t.to_dict() for t in self.tool_calls]

            # EXECUTION TIME
            result["execution_time_ms"] = (time.time() - self.start_time) * 1000

            # DECISION TRACE
            result["decision_trace"] = self._generate_decision_trace(result)

            # LOG RUN
            self.logger.log_run(
                run_id=result["run_id"],
                subject=subject,
                description=description,
                predicted_category=result["classification"]["category"],
                predicted_priority=result["priority"]["priority"],
                confidence=result["confidence"]["confidence_score"],
                risk_score=result["risk"]["risk_score"],
                escalated=result["escalated"],
                execution_time_ms=result["execution_time_ms"],
                status=result["status"],
            )

            return result

        except Exception as e:
            return self._error_result(result, str(e))

    def _log_current_state(self):
        """Helper to log current state for debugging"""
        if self.state_machine:
            current = self.state_machine.current_state
            print(f"Current state: {current.value if current else 'None'}")

    def _transition(self, event, metadata: Dict[str, Any] = None):

        if self.state_machine is None:
            return False

        return self.state_machine.transition(event, metadata)

    def _validate_input(self, subject: str, description: str):

        if not subject or len(subject.strip()) < 3:
            return False

        if not description or len(description.strip()) < 10:
            return False

        return True

    def _classify_ticket(self, subject: str, description: str):

        start = time.time()

        text = f"{subject} {description}"

        category, confidence, probs = self.model.predict_with_probs(text)

        exec_time = (time.time() - start) * 1000

        try:
            category_enum = Category(category)
        except Exception:
            category_enum = Category.UNCLEAR

        input_model = ClassifyTicketInput(subject=subject, description=description)

        output_model = ClassifyTicketOutput(
            category=category_enum,
            confidence=float(confidence),
            top_categories=probs,
            execution_time_ms=exec_time,
        )

        self.tool_calls.append(
            ToolCall("classify_ticket", input_model, output_model, exec_time)
        )

        return {
            "category": category_enum.value,
            "confidence": float(confidence),
            "top_categories": probs,
            "execution_time_ms": exec_time,
        }

    def _compute_risk_score(self, subject, description, classification):

        start = time.time()

        category = Category(classification["category"])

        risk_score, components = self.risk_engine.compute_risk_score(
            category=category,
            description=description,
            urgency_keywords=[],
            sentiment_score=0.0,
        )

        exec_time = (time.time() - start) * 1000

        input_model = ComputeRiskScoreInput(
            category=category,
            description=description,
            urgency_keywords=[],
            sentiment_score=0.0,
        )

        output_model = ComputeRiskScoreOutput(
            risk_score=risk_score,
            components=components,
            breakdown=str(components),
            execution_time_ms=exec_time,
        )

        self.tool_calls.append(
            ToolCall("compute_risk_score", input_model, output_model, exec_time)
        )

        return {
            "risk_score": risk_score,
            "components": components,
            "execution_time_ms": exec_time,
        }

    def _assign_priority(self, category, risk_score):

        start = time.time()

        category_enum = Category(category)

        priority_str = self.risk_engine.get_priority_from_risk(risk_score)

        priority_map = {
            "high": Priority.HIGH,
            "medium": Priority.MEDIUM,
            "low": Priority.LOW,
        }

        priority_enum = priority_map[priority_str]

        exec_time = (time.time() - start) * 1000

        input_model = AssignPriorityInput(
            risk_score=risk_score,
            category=category_enum,
        )

        output_model = AssignPriorityOutput(
            priority=priority_enum,
            reasoning=f"{priority_str} priority from risk score {risk_score:.2f}",
            execution_time_ms=exec_time,
        )

        self.tool_calls.append(
            ToolCall("assign_priority", input_model, output_model, exec_time)
        )

        return {
            "priority": priority_enum.value,
            "execution_time_ms": exec_time,
        }

    def _check_confidence(self, classification_confidence, risk_score, override):

        start = time.time()

        conf_score, _ = self.confidence_engine.compute_confidence(
            classification_confidence,
            risk_score,
            0.0,
        )

        should_escalate, reasoning = self.confidence_engine.should_escalate(
            conf_score,
            risk_score,
            override,
        )

        exec_time = (time.time() - start) * 1000

        input_model = CheckConfidenceInput(
            classification_confidence=classification_confidence,
            risk_score=risk_score,
            threshold=self.config.confidence_threshold,
        )

        output_model = CheckConfidenceOutput(
            should_escalate=should_escalate,
            confidence_score=conf_score,
            reasoning=reasoning,
            execution_time_ms=exec_time,
        )

        self.tool_calls.append(
            ToolCall("check_confidence", input_model, output_model, exec_time)
        )

        return {
            "should_escalate": should_escalate,
            "confidence_score": conf_score,
            "reasoning": reasoning,
            "execution_time_ms": exec_time,
        }

    def _generate_decision_trace(self, result):

        trace = f"""
=== DECISION TRACE ===
Run ID: {result['run_id']}
Status: {result['status']}

--- Classification ---
Category: {result['classification']['category']}
Confidence: {result['classification']['confidence']:.2%}
Top Categories: {', '.join([f'{k}:{v:.2f}' for k, v in sorted(result['classification']['top_categories'].items(), key=lambda x: x[1], reverse=True)[:3]])}

--- Risk Analysis ---
Risk Score: {result['risk']['risk_score']:.2f}
Breakdown: Category Base: {result['risk']['components'].get('category_base', 0):.2f} | Urgency: {result['risk']['components'].get('urgency', 0):.2f} | Sentiment: {result['risk']['components'].get('sentiment', 0):.2f} | Uncertainty: {result['risk']['components'].get('uncertainty', 0):.2f} | Final Score: {result['risk']['risk_score']:.2f}

--- Priority & Confidence ---
Priority: {result['priority']['priority'].capitalize()}
Confidence: {result['confidence']['confidence_score']:.1%}
Escalated: {result['escalated']}
Reason: {result['confidence']['reasoning']}

Execution Time: {result['execution_time_ms']:.1f}ms
"""
        return trace.strip()

    def _error_result(self, result: Dict[str, Any], error_msg: str):

        result["status"] = "error"
        result["error"] = error_msg
        result["execution_time_ms"] = (time.time() - self.start_time) * 1000

        return result
