"""Baseline keyword classifier for comparison."""

from src.tools import Category, Priority


class BaselineClassifier:
    """Simple rule-based baseline classifier for benchmarking."""
    
    # Keyword patterns for each category
    CATEGORY_KEYWORDS = {
        Category.BUG: [
            "bug", "crash", "broken", "error", "error message",
            "not working", "failed", "failing", "exception",
            "doesn't work", "doesn't work", "not functioning",
        ],
        Category.SECURITY: [
            "security", "vulnerability", "attack", "breach", "exploit",
            "password", "authentication", "authorization", "hack",
            "injection", "xss", "sql injection", "malware",
        ],
        Category.INFRASTRUCTURE: [
            "infrastructure", "server", "database", "deployment",
            "scalability", "downtime", "outage", "latency",
            "performance", "load", "cpu", "memory",
        ],
        Category.PERFORMANCE: [
            "performance", "slow", "lag", "latency", "sluggish",
            "speed", "optimization", "cpu", "memory", "response time",
        ],
        Category.FEATURE_REQUEST: [
            "feature", "feature request", "add", "enhancement",
            "implement", "new", "capability", "support for",
            "would be nice", "can we", "please add", "suggestion",
        ],
        Category.DOCUMENTATION: [
            "documentation", "docs", "unclear", "confusing",
            "example", "tutorial", "guide", "readme", "comment",
            "explain", "missing docs",
        ],
    }
    
    # Priority keywords
    PRIORITY_KEYWORDS = {
        Priority.HIGH: [
            "critical", "urgent", "asap", "emergency",
            "down", "downtime", "broken", "security",
        ],
        Priority.MEDIUM: [
            "important", "soon", "moderate", "moderate impact",
        ],
    }
    
    def classify_ticket(self, subject: str, description: str) -> tuple[Category, float]:
        """
        Classify ticket using keyword matching.
        
        Returns: (category, confidence)
        """
        combined_text = (subject + " " + description).lower()
        
        # Score each category
        category_scores = {}
        
        for category, keywords in self.CATEGORY_KEYWORDS.items():
            score = 0
            matched_keywords = []
            
            for keyword in keywords:
                if keyword in combined_text:
                    score += 1
                    matched_keywords.append(keyword)
            
            category_scores[category] = {
                "score": score,
                "keywords": matched_keywords,
            }
        
        # Find best category
        best_category = max(
            category_scores.items(),
            key=lambda x: x[1]["score"],
        )[0]
        
        best_score = category_scores[best_category]["score"]
        
        # Compute confidence based on match strength
        max_possible_score = max(
            len(keywords) for keywords in self.CATEGORY_KEYWORDS.values()
        )
        
        if best_score == 0:
            # No keywords matched, default to UNCLEAR
            confidence = 0.3
            best_category = Category.UNCLEAR
        else:
            # Confidence based on percentage of keywords matched
            confidence = min(1.0, (best_score / max_possible_score) * 0.8 + 0.2)
        
        return best_category, confidence
    
    def assign_priority(self, subject: str, description: str, category: Category) -> Priority:
        """Assign priority based on keywords."""
        combined_text = (subject + " " + description).lower()
        
        # Check for high priority indicators
        for keyword in self.PRIORITY_KEYWORDS[Priority.HIGH]:
            if keyword in combined_text:
                return Priority.HIGH
        
        # Check for medium priority
        for keyword in self.PRIORITY_KEYWORDS[Priority.MEDIUM]:
            if keyword in combined_text:
                return Priority.MEDIUM
        
        # Default based on category
        if category == Category.SECURITY:
            return Priority.HIGH
        elif category == Category.INFRASTRUCTURE:
            return Priority.MEDIUM
        elif category == Category.BUG:
            return Priority.MEDIUM
        else:
            return Priority.LOW
