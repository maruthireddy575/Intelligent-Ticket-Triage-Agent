
"""ML model loading and inference (dataset-trained model)."""

import pickle
import re
from pathlib import Path


class MLModel:
    """ML Model for ticket classification using pre-trained model."""

    def __init__(self, model_path: str = None, vectorizer_path: str = None):

        if model_path is None:
            model_path = Path(__file__).parent.parent / "models" / "model.pkl"

        if vectorizer_path is None:
            vectorizer_path = Path(__file__).parent.parent / "models" / "vectorizer.pkl"

        self.model_path = Path(model_path)
        self.vectorizer_path = Path(vectorizer_path)

        self.model = None
        self.vectorizer = None
        self.classes = None

        self.load()

    # ---------------------------------------------------------------------

    def load(self):
        """Load trained model and vectorizer."""

        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Model file not found at {self.model_path}. Train the model first."
            )

        if not self.vectorizer_path.exists():
            raise FileNotFoundError(
                f"Vectorizer file not found at {self.vectorizer_path}. Train the model first."
            )

        with open(self.model_path, "rb") as f:
            self.model = pickle.load(f)

        with open(self.vectorizer_path, "rb") as f:
            self.vectorizer = pickle.load(f)

        if hasattr(self.model, "classes_"):
            self.classes = self.model.classes_

    # ---------------------------------------------------------------------

    def _clean_text(self, text: str) -> str:
        """Light text preprocessing for more stable predictions."""

        text = text.lower()

        text = re.sub(r"http\S+", " ", text)
        text = re.sub(r"[^a-z0-9\s]", " ", text)

        text = re.sub(r"\s+", " ", text).strip()

        return text

    # ---------------------------------------------------------------------

    def _vectorize(self, text: str):
        """Vectorize cleaned text."""

        clean_text = self._clean_text(text)

        return self.vectorizer.transform([clean_text])

    # ---------------------------------------------------------------------

    def predict(self, text: str) -> tuple[str, float]:
        """
        Predict category.

        Returns
        -------
        (category, confidence)
        """

        X = self._vectorize(text)

        prediction = self.model.predict(X)[0]

        probs = self.model.predict_proba(X)[0]

        confidence = float(max(probs))

        return prediction, confidence

    # ---------------------------------------------------------------------

    def predict_with_probs(self, text: str) -> tuple[str, float, dict]:
        """
        Predict category with full probability distribution.
        """

        X = self._vectorize(text)

        prediction = self.model.predict(X)[0]

        probabilities = self.model.predict_proba(X)[0]

        probs_dict = {}

        for i, class_name in enumerate(self.classes):
            probs_dict[class_name] = float(probabilities[i])

        confidence = float(max(probabilities))

        return prediction, confidence, probs_dict


# ---------------------------------------------------------------------
# Global model instance (singleton)
# ---------------------------------------------------------------------

_model = None


def get_model() -> MLModel:
    """Get or create global model instance."""
    global _model
    if _model is None:
        _model = MLModel()
    return _model
