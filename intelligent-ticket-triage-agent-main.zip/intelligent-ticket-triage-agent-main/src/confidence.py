"""Confidence scoring and escalation decision logic."""

from src.config import get_config


class ConfidenceEngine:
    """Engine for computing confidence scores and escalation decisions."""

    def __init__(self):
        self.config = get_config()
        self.confidence_threshold = self.config.confidence_threshold

    def compute_confidence(
        self,
        classification_confidence: float,
        risk_score: float,
        category_diversity: float = 0.0,
    ):
        """
        Compute overall confidence score.
        """

        model_conf_weight = 0.6

        risk_consistency = 1.0 - abs(risk_score - 0.5) / 0.5
        risk_weight = 0.25

        diversity_weight = 0.15

        confidence = (
            classification_confidence * model_conf_weight
            + risk_consistency * risk_weight
            + (1.0 - category_diversity) * diversity_weight
        )

        confidence = min(1.0, max(0.0, confidence))

        should_escalate = confidence < self.confidence_threshold

        return confidence, should_escalate

    def should_escalate(
        self,
        confidence_score: float,
        risk_score: float,
        override: bool = False,
    ):

        if override:
            return True, "Manual escalation override"

        reasons = []
        should_escalate = False

        if confidence_score < self.confidence_threshold:
            should_escalate = True
            reasons.append(
                f"Low confidence ({confidence_score:.1%}) below threshold "
                f"({self.confidence_threshold:.1%})"
            )

        if risk_score >= 0.9:
            should_escalate = True
            reasons.append(f"Critical risk score ({risk_score:.1%})")

        elif risk_score >= 0.85 and confidence_score < 0.8:
            should_escalate = True
            reasons.append(
                f"High risk ({risk_score:.1%}) with moderate confidence "
                f"({confidence_score:.1%})"
            )

        reasoning = "; ".join(reasons) if reasons else "Routine processing"

        return should_escalate, reasoning

    def get_confidence_gauge_data(self, confidence: float):

        return {
            "confidence": confidence,
            "threshold": self.confidence_threshold,
            "status": "high" if confidence >= self.confidence_threshold else "low",
            "percentage": f"{confidence * 100:.1f}%",
        }