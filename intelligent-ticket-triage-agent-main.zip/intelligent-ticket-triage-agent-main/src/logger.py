"""Logging system with SQLite and JSONL backup."""

import sqlite3
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
import threading


class TriageLogger:
    """Logger for ticket triage system with SQLite and JSONL backup."""
    
    def __init__(self, db_path: str = None, jsonl_path: str = None):
        if db_path is None:
            db_path = Path(__file__).parent.parent / "database" / "runs.db"
        if jsonl_path is None:
            jsonl_path = Path(__file__).parent.parent / "database" / "runs.jsonl"
        
        self.db_path = Path(db_path)
        self.jsonl_path = Path(jsonl_path)
        
        # Ensure directories exist
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.jsonl_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._lock = threading.Lock()
        self._init_db()
    
    def _init_db(self):
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    subject TEXT,
                    description TEXT,
                    predicted_category TEXT,
                    predicted_priority TEXT,
                    confidence REAL,
                    risk_score REAL,
                    escalated BOOLEAN,
                    execution_time_ms REAL,
                    status TEXT
                )
                """
            )
            
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    data TEXT,
                    FOREIGN KEY (run_id) REFERENCES runs(id)
                )
                """
            )
            
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS tool_calls (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    tool_name TEXT NOT NULL,
                    input_data TEXT,
                    output_data TEXT,
                    execution_time_ms REAL,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (run_id) REFERENCES runs(id)
                )
                """
            )
            
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS state_transitions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    previous_state TEXT NOT NULL,
                    event TEXT NOT NULL,
                    next_state TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    metadata TEXT,
                    FOREIGN KEY (run_id) REFERENCES runs(id)
                )
                """
            )
            
            conn.commit()
    
    def log_run(
        self,
        run_id: str,
        subject: str,
        description: str,
        predicted_category: str,
        predicted_priority: str,
        confidence: float,
        risk_score: float,
        escalated: bool,
        execution_time_ms: float,
        status: str = "completed",
    ):
        """Log a complete triage run."""
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO runs 
                    (id, timestamp, subject, description, predicted_category, 
                     predicted_priority, confidence, risk_score, escalated, 
                     execution_time_ms, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        datetime.now().isoformat(),
                        subject,
                        description,
                        predicted_category,
                        predicted_priority,
                        confidence,
                        risk_score,
                        escalated,
                        execution_time_ms,
                        status,
                    ),
                )
                conn.commit()
            
            # Also log to JSONL
            self._log_to_jsonl(
                {
                    "type": "run",
                    "run_id": run_id,
                    "timestamp": datetime.now().isoformat(),
                    "subject": subject,
                    "description": description,
                    "predicted_category": predicted_category,
                    "predicted_priority": predicted_priority,
                    "confidence": confidence,
                    "risk_score": risk_score,
                    "escalated": escalated,
                    "execution_time_ms": execution_time_ms,
                    "status": status,
                }
            )
    
    def log_event(self, run_id: str, event_type: str, data: Dict[str, Any] = None):
        """Log an event in a run."""
        if data is None:
            data = {}
        
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO events (run_id, event_type, timestamp, data)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        event_type,
                        datetime.now().isoformat(),
                        json.dumps(data),
                    ),
                )
                conn.commit()
            
            # Also log to JSONL
            self._log_to_jsonl(
                {
                    "type": "event",
                    "run_id": run_id,
                    "event_type": event_type,
                    "timestamp": datetime.now().isoformat(),
                    "data": data,
                }
            )
    
    def log_tool_call(
        self,
        run_id: str,
        tool_name: str,
        input_data: Dict[str, Any],
        output_data: Dict[str, Any],
        execution_time_ms: float,
    ):
        """Log a tool call."""
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO tool_calls 
                    (run_id, tool_name, input_data, output_data, execution_time_ms, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        tool_name,
                        json.dumps(input_data),
                        json.dumps(output_data),
                        execution_time_ms,
                        datetime.now().isoformat(),
                    ),
                )
                conn.commit()
            
            # Also log to JSONL
            self._log_to_jsonl(
                {
                    "type": "tool_call",
                    "run_id": run_id,
                    "tool_name": tool_name,
                    "input": input_data,
                    "output": output_data,
                    "execution_time_ms": execution_time_ms,
                    "timestamp": datetime.now().isoformat(),
                }
            )
    
    def log_state_transition(
        self,
        run_id: str,
        previous_state: str,
        event: str,
        next_state: str,
        metadata: Dict[str, Any] = None,
    ):
        """Log a state transition."""
        if metadata is None:
            metadata = {}
        
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """
                    INSERT INTO state_transitions 
                    (run_id, previous_state, event, next_state, timestamp, metadata)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        previous_state,
                        event,
                        next_state,
                        datetime.now().isoformat(),
                        json.dumps(metadata),
                    ),
                )
                conn.commit()
            
            # Also log to JSONL
            self._log_to_jsonl(
                {
                    "type": "state_transition",
                    "run_id": run_id,
                    "previous_state": previous_state,
                    "event": event,
                    "next_state": next_state,
                    "metadata": metadata,
                    "timestamp": datetime.now().isoformat(),
                }
            )
    
    def _log_to_jsonl(self, record: Dict[str, Any]):
        """Append record to JSONL file."""
        with open(self.jsonl_path, "a") as f:
            f.write(json.dumps(record) + "\n")
    
    def get_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        """Get a run by ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM runs WHERE id = ?", (run_id,)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_all_runs(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get all runs."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM runs ORDER BY timestamp DESC LIMIT ?", (limit,)
            )
            return [dict(row) for row in cursor.fetchall()]
    
    def get_run_events(self, run_id: str) -> List[Dict[str, Any]]:
        """Get all events for a run."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM events WHERE run_id = ? ORDER BY timestamp",
                (run_id,),
            )
            events = [dict(row) for row in cursor.fetchall()]
            
            # Parse JSON data
            for event in events:
                if event["data"]:
                    event["data"] = json.loads(event["data"])
            
            return events
    
    def get_run_tool_calls(self, run_id: str) -> List[Dict[str, Any]]:
        """Get all tool calls for a run."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM tool_calls WHERE run_id = ? ORDER BY timestamp",
                (run_id,),
            )
            calls = [dict(row) for row in cursor.fetchall()]
            
            # Parse JSON data
            for call in calls:
                if call["input_data"]:
                    call["input_data"] = json.loads(call["input_data"])
                if call["output_data"]:
                    call["output_data"] = json.loads(call["output_data"])
            
            return calls
    
    def get_run_state_transitions(self, run_id: str) -> List[Dict[str, Any]]:
        """Get all state transitions for a run."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM state_transitions WHERE run_id = ? ORDER BY timestamp",
                (run_id,),
            )
            transitions = [dict(row) for row in cursor.fetchall()]
            
            # Parse JSON metadata
            for transition in transitions:
                if transition["metadata"]:
                    transition["metadata"] = json.loads(transition["metadata"])
            
            return transitions
