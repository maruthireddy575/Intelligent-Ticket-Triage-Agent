
"""
Train the ML model for Intelligent Ticket Triage Agent
This script trains the model and saves it to the models/ folder
"""

import pandas as pd
import numpy as np
import pickle
import re
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# Configuration
RANDOM_SEED = 42
TEST_SIZE = 0.2
MAX_FEATURES = 1000

# Paths
MODEL_PATH = Path("models/model.pkl")
VECTORIZER_PATH = Path("models/vectorizer.pkl")
MODEL_PATH.parent.mkdir(exist_ok=True)

def clean_text(text):
    """Clean and preprocess text (matching ml_model.py)"""
    if pd.isna(text) or not isinstance(text, str):
        return ""
    
    text = text.lower()
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    
    return text

def load_builtin_training_data():
    """
    Create training data based on the categories in your system
    This matches the expected categories from your app
    """
    
    # Training data with 100+ samples across all categories
    training_data = [
        # Billing issues (20 samples)
        ("I was charged twice for my subscription", "Billing"),
        ("Please refund the duplicate payment", "Billing"),
        ("My invoice shows wrong amount", "Billing"),
        ("Can't update my payment method", "Billing"),
        ("When will I get my money back", "Billing"),
        ("My credit card was charged but subscription not active", "Billing"),
        ("I need a copy of my receipt", "Billing"),
        ("The price increased without notice", "Billing"),
        ("Discount code not working at checkout", "Billing"),
        ("I was charged after canceling", "Billing"),
        ("Payment method declined", "Billing"),
        ("International transaction fee question", "Billing"),
        ("Upgraded but still charged old price", "Billing"),
        ("Refund not processed after 5 days", "Billing"),
        ("Invoice missing from account", "Billing"),
        ("Currency conversion error on payment", "Billing"),
        ("Annual subscription renewal question", "Billing"),
        ("Can I get a pro-rated refund", "Billing"),
        ("Payment not going through", "Billing"),
        ("Billing address update needed", "Billing"),
        
        # Technical issues (20 samples)
        ("The application crashes when I try to login", "Technical"),
        ("Database connection error occurred", "Technical"),
        ("Server is down, cannot access the system", "Technical"),
        ("API returns 500 error", "Technical"),
        ("Page loads very slowly", "Technical"),
        ("Mobile app crashes on startup", "Technical"),
        ("Export function not working", "Technical"),
        ("Integration with third-party API failing", "Technical"),
        ("SSL certificate expired", "Technical"),
        ("Load balancer configuration issue", "Technical"),
        ("Memory leak in production", "Technical"),
        ("Deployment pipeline failing", "Technical"),
        ("Database queries timing out", "Technical"),
        ("Authentication service unavailable", "Technical"),
        ("File upload not working", "Technical"),
        ("Email notifications not sending", "Technical"),
        ("Search functionality broken", "Technical"),
        ("Data not syncing across devices", "Technical"),
        ("Login session keeps expiring", "Technical"),
        ("API rate limiting too strict", "Technical"),
        
        # Account issues (20 samples)
        ("I forgot my password", "Account"),
        ("Can't login to my account", "Account"),
        ("Someone hacked my account", "Account"),
        ("How to change my email", "Account"),
        ("Account locked after multiple attempts", "Account"),
        ("Two-factor authentication not working", "Account"),
        ("Cannot change profile information", "Account"),
        ("Unable to deactivate account", "Account"),
        ("Permission denied for admin features", "Account"),
        ("Account verification not working", "Account"),
        ("Role change request", "Account"),
        ("Cannot connect social media accounts", "Account"),
        ("Account suspended incorrectly", "Account"),
        ("Username already taken error", "Account"),
        ("Cannot upgrade account type", "Account"),
        ("Account settings not saving", "Account"),
        ("Multiple accounts merged incorrectly", "Account"),
        ("Account recovery email not sent", "Account"),
        ("Linked account disconnected", "Account"),
        ("Account activity shows unknown logins", "Account"),
        
        # Delivery issues (20 samples)
        ("My package hasn't arrived", "Delivery"),
        ("Where is my order", "Delivery"),
        ("Shipping was delayed", "Delivery"),
        ("Wrong item delivered", "Delivery"),
        ("Tracking number not working", "Delivery"),
        ("Package damaged during shipping", "Delivery"),
        ("Delivery address incorrect", "Delivery"),
        ("Partial shipment received", "Delivery"),
        ("Customs clearance delay", "Delivery"),
        ("Return label not working", "Delivery"),
        ("International shipping cost unclear", "Delivery"),
        ("Expedited shipping not processed", "Delivery"),
        ("Delivery date changed", "Delivery"),
        ("Package marked delivered but not received", "Delivery"),
        ("Shipping insurance claim", "Delivery"),
        ("Delivery to wrong address", "Delivery"),
        ("Signature required but no one home", "Delivery"),
        ("Cross-border shipping fees", "Delivery"),
        ("Delivery time window missed", "Delivery"),
        ("Package returned to sender", "Delivery"),
        
        # General inquiries (20 samples)
        ("How does this work", "General"),
        ("Need help with your service", "General"),
        ("What are your business hours", "General"),
        ("Contact support please", "General"),
        ("Thanks for your help", "General"),
        ("Do you offer phone support", "General"),
        ("Where can I find documentation", "General"),
        ("Is there a mobile app", "General"),
        ("Can I export my data", "General"),
        ("How to cancel subscription", "General"),
        ("Privacy policy questions", "General"),
        ("Feature request for dark mode", "General"),
        ("Tutorial videos availability", "General"),
        ("System requirements question", "General"),
        ("Compatibility with other software", "General"),
        ("Data retention policy", "General"),
        ("Security practices overview", "General"),
        ("Roadmap for new features", "General"),
        ("Partnership opportunities", "General"),
        ("Press inquiries", "General"),
    ]
    
    return training_data

def load_csv_data():
    """Load data from CSV file if available"""
    csv_path = input("\n📁 Enter path to your CSV file (or press Enter to skip): ").strip()
    
    if not csv_path:
        return []
    
    if not Path(csv_path).exists():
        print(f"⚠️ File not found: {csv_path}")
        return []
    
    print(f"\n📂 Loading CSV: {csv_path}")
    
    # Try different encodings
    encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
    df = None
    
    for encoding in encodings:
        try:
            df = pd.read_csv(csv_path, encoding=encoding)
            print(f"✓ Read with encoding: {encoding}")
            break
        except:
            continue
    
    if df is None:
        print("❌ Could not read CSV file")
        return []
    
    print(f"\n📊 CSV Columns: {list(df.columns)}")
    print("\nFirst 3 rows:")
    print(df.head(3))
    
    # Try to identify text and category columns
    text_col = None
    category_col = None
    
    # Common column names
    text_keywords = ['text', 'description', 'body', 'message', 'ticket', 'issue', 'content']
    category_keywords = ['category', 'type', 'class', 'label', 'department', 'group']
    
    for col in df.columns:
        col_lower = col.lower()
        if any(k in col_lower for k in text_keywords):
            text_col = col
        if any(k in col_lower for k in category_keywords):
            category_col = col
    
    if text_col is None:
        text_col = df.columns[0]  # Assume first column is text
        print(f"ℹ️ Using first column as text: '{text_col}'")
    
    if category_col is None:
        category_col = df.columns[1]  # Assume second column is category
        print(f"ℹ️ Using second column as category: '{category_col}'")
    
    print(f"\n✅ Using:")
    print(f"   Text column: '{text_col}'")
    print(f"   Category column: '{category_col}'")
    
    # Extract and clean data
    texts = df[text_col].fillna("").astype(str).apply(clean_text).tolist()
    categories = df[category_col].fillna("").astype(str).tolist()
    
    # Filter out empty texts
    valid_data = [(t, c) for t, c in zip(texts, categories) if t and len(t) > 10]
    
    print(f"\n📊 CSV Data Summary:")
    print(f"   Total rows: {len(df)}")
    print(f"   Valid rows: {len(valid_data)}")
    
    return valid_data

def prepare_training_data():
    """Combine built-in data with CSV data if available"""
    print("\n" + "="*60)
    print("PREPARING TRAINING DATA")
    print("="*60)
    
    # Load built-in data
    builtin_data = load_builtin_training_data()
    print(f"\n📚 Built-in samples: {len(builtin_data)}")
    
    # Try to load CSV data
    csv_data = load_csv_data()
    
    # Combine data
    if csv_data:
        all_data = builtin_data + csv_data
        print(f"\n📊 Total samples after combining: {len(all_data)}")
    else:
        all_data = builtin_data
        print(f"\n📊 Using only built-in data: {len(all_data)} samples")
    
    # Split into texts and labels
    texts = [item[0] for item in all_data]
    labels = [item[1] for item in all_data]
    
    # Show category distribution
    from collections import Counter
    dist = Counter(labels)
    print("\n📈 Category Distribution:")
    for cat in ['Billing', 'Technical', 'Account', 'Delivery', 'General']:
        count = dist.get(cat, 0)
        percentage = (count / len(labels)) * 100 if labels else 0
        print(f"   {cat}: {count} ({percentage:.1f}%)")
    
    return texts, labels

def train_model(texts, labels):
    """Train the model"""
    print("\n" + "="*60)
    print("TRAINING MODEL")
    print("="*60)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=labels
    )
    
    print(f"\n📊 Data Split:")
    print(f"   Training: {len(X_train)} samples")
    print(f"   Testing: {len(X_test)} samples")
    
    # Create vectorizer
    print("\n🔄 Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        max_features=MAX_FEATURES,
        ngram_range=(1, 2),
        stop_words='english',
        lowercase=True
    )
    
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    print(f"   Vocabulary size: {len(vectorizer.vocabulary_)}")
    print(f"   Training matrix shape: {X_train_vec.shape}")
    
    # Train classifier
    print("\n🔄 Training Logistic Regression classifier...")
    classifier = LogisticRegression(
        max_iter=1000,
        random_state=RANDOM_SEED,
        multi_class='multinomial',
        solver='lbfgs',
        C=1.0,
        class_weight='balanced'
    )
    
    classifier.fit(X_train_vec, y_train)
    
    # Evaluate
    y_pred = classifier.predict(X_test_vec)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\n✅ Test Accuracy: {accuracy:.2%}")
    
    # Detailed metrics
    print("\n📋 Classification Report:")
    print(classification_report(y_test, y_pred))
    
    # Create confusion matrix
    plt.figure(figsize=(10, 8))
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=classifier.classes_,
                yticklabels=classifier.classes_)
    plt.title('Confusion Matrix - Ticket Classification')
    plt.xlabel('Predicted Category')
    plt.ylabel('Actual Category')
    plt.tight_layout()
    plt.savefig('models/confusion_matrix.png')
    print(f"\n📊 Confusion matrix saved to: models/confusion_matrix.png")
    plt.show()
    
    return vectorizer, classifier

def save_model(vectorizer, classifier):
    """Save model and vectorizer"""
    print("\n💾 Saving model...")
    
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(classifier, f)
    
    with open(VECTORIZER_PATH, 'wb') as f:
        pickle.dump(vectorizer, f)
    
    print(f"✅ Model saved to: {MODEL_PATH}")
    print(f"✅ Vectorizer saved to: {VECTORIZER_PATH}")
    
    # Verify files were created
    if MODEL_PATH.exists() and VECTORIZER_PATH.exists():
        print(f"✅ Files verified: {MODEL_PATH.stat().st_size/1024:.1f} KB, {VECTORIZER_PATH.stat().st_size/1024:.1f} KB")
    else:
        print("❌ Error: Files were not saved properly")

def test_model(vectorizer, classifier):
    """Test the trained model with sample queries"""
    print("\n" + "="*60)
    print("TESTING MODEL WITH SAMPLE QUERIES")
    print("="*60)
    
    test_queries = [
        "I was charged twice for my subscription",
        "The app keeps crashing when I try to login",
        "I forgot my password and can't access my account",
        "Where is my package? It's been 2 weeks",
        "How do I use this feature?",
        "Security issue with my account",
        "API returns 500 error",
        "Can't update payment method",
        "Delivery address is wrong",
        "What are your support hours?",
    ]
    
    for query in test_queries:
        cleaned = clean_text(query)
        X_test = vectorizer.transform([cleaned])
        pred = classifier.predict(X_test)[0]
        probs = classifier.predict_proba(X_test)[0]
        confidence = max(probs)
        
        print(f"\n📝 Query: {query}")
        print(f"   → Category: {pred}")
        print(f"   → Confidence: {confidence:.2%}")
        
        # Show top 3 probabilities
        top_indices = np.argsort(probs)[-3:][::-1]
        print("   Top predictions:")
        for idx in top_indices:
            if probs[idx] > 0.05:  # Only show if >5%
                print(f"      - {classifier.classes_[idx]}: {probs[idx]:.2%}")

def main():
    print("="*70)
    print(" INTELLIGENT TICKET TRIAGE AGENT - MODEL TRAINING")
    print("="*70)
    
    # Prepare training data
    texts, labels = prepare_training_data()
    
    if len(texts) < 10:
        print("\n❌ Not enough data to train model. Need at least 10 samples.")
        return
    
    # Train model
    vectorizer, classifier = train_model(texts, labels)
    
    # Save model
    save_model(vectorizer, classifier)
    
    # Test model
    test_model(vectorizer, classifier)
    
    print("\n" + "="*70)
    print("✅ TRAINING COMPLETE!")
    print("="*70)
    print("\n📱 You can now run the app with:")
    print("   streamlit run app.py")
    print("\nThe model will be automatically loaded by ml_model.py")

if __name__ == "__main__":
    main()
