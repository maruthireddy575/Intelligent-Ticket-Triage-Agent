"""Risk scoring engine for ticket triage."""

from src.tools import Category
from src.config import get_config


URGENCY_KEYWORDS = {
    "critical": 0.40,
    "urgent": 0.35,
    "asap": 0.30,
    "emergency": 0.45,
    "down": 0.40,
    "broken": 0.30,
    "crash": 0.40,
    "blocked": 0.35,
    "failed": 0.30,
    "not working": 0.30,
}


CATEGORY_BASE_RISK = {
    Category.BUG: 0.75,
    Category.SECURITY: 0.95,
    Category.INFRASTRUCTURE: 0.85,
    Category.PERFORMANCE: 0.65,
    Category.FEATURE_REQUEST: 0.20,
    Category.DOCUMENTATION: 0.10,
    Category.UNCLEAR: 0.40,
}


class RiskEngine:
    """Engine for computing risk scores."""

    def __init__(self):
        self.config = get_config()

    def compute_risk_score(
        self,
        category: Category,
        description: str,
        sentiment_score: float = 0.0,
        urgency_keywords: list = None,
    ):

        urgency_keywords = urgency_keywords or []

        category_base = CATEGORY_BASE_RISK.get(category, 0.3)

        urgency_score = self._calculate_urgency_score(description, urgency_keywords)

        negative_sentiment = max(0, -sentiment_score)

        uncertainty_score = self._calculate_uncertainty_score(description)

        # Stronger weighted scoring
        total_score = (
            category_base * 0.55
            + urgency_score * 0.30
            + negative_sentiment * 0.10
            + uncertainty_score * 0.05
        )

        risk_score = min(1.0, max(0.0, total_score))

        components = {
            "category_base": round(category_base, 3),
            "urgency": round(urgency_score, 3),
            "sentiment": round(negative_sentiment, 3),
            "uncertainty": round(uncertainty_score, 3),
            "total_raw": round(total_score, 3),
            "final": round(risk_score, 3),
        }

        return risk_score, components

    def _calculate_urgency_score(self, description: str, keywords: list):

        desc_lower = description.lower()
        urgency_score = 0.0

        for keyword, weight in URGENCY_KEYWORDS.items():
            if keyword in desc_lower:
                urgency_score = max(urgency_score, weight)

        for keyword in keywords:
            keyword_lower = keyword.lower()
            for kw, weight in URGENCY_KEYWORDS.items():
                if kw in keyword_lower:
                    urgency_score = max(urgency_score, weight)

        return min(1.0, urgency_score)

    def _calculate_uncertainty_score(self, description: str):

        uncertainty = 0.0
        desc_lower = description.lower()

        if len(description) < 50:
            uncertainty += 0.3
        elif len(description) < 100:
            uncertainty += 0.1

        vague_terms = ["something", "some", "issue", "problem", "weird", "strange"]
        vague_count = sum(1 for term in vague_terms if term in desc_lower)

        uncertainty += min(0.3, vague_count * 0.1)

        question_count = description.count("?")
        uncertainty += min(0.2, question_count * 0.1)

        return min(1.0, uncertainty)

    def get_priority_from_risk(self, risk_score: float):

        if risk_score >= 0.75:
            return "high"
        elif risk_score >= 0.45:
            return "medium"
        else:
            return "low"