
"""
Train model using your CSV file + built-in data
Combines both sources for better training
"""

import pandas as pd
import numpy as np
import pickle
import re
from pathlib import Path
from src.ml_model import TRAINING_DATA
from src.tools import Category

# Configuration
RANDOM_SEED = 42
MODEL_PATH = Path("models/model.pkl")
VECTORIZER_PATH = Path("models/vectorizer.pkl")
MODEL_PATH.parent.mkdir(exist_ok=True)

def clean_text(text):
    """Clean and preprocess text"""
    if pd.isna(text) or not isinstance(text, str):
        return ""
    text = str(text).lower()
    text = re.sub(r'[^a-zA-Z\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def load_csv_data(csv_path):
    """Load data from CSV file"""
    print(f"\n📂 Loading CSV: {csv_path}")
    
    # Try different encodings
    encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
    df = None
    
    for encoding in encodings:
        try:
            df = pd.read_csv(csv_path, encoding=encoding)
            print(f"✓ Read with encoding: {encoding}")
            break
        except:
            continue
    
    if df is None:
        raise Exception("Could not read CSV file")
    
    print(f"\n📊 CSV Columns: {list(df.columns)}")
    print("\nFirst 3 rows:")
    print(df.head(3))
    
    # Identify text and category columns
    text_col = None
    category_col = None
    
    # Common column names
    text_keywords = ['text', 'description', 'body', 'message', 'ticket', 'issue']
    category_keywords = ['category', 'type', 'class', 'label', 'department']
    
    for col in df.columns:
        col_lower = col.lower()
        if any(k in col_lower for k in text_keywords):
            text_col = col
        if any(k in col_lower for k in category_keywords):
            category_col = col
    
    # If not found, ask user
    if text_col is None:
        print("\n🔍 Could not auto-detect text column")
        print("Available columns:")
        for i, col in enumerate(df.columns, 1):
            print(f"{i}. {col}")
        choice = int(input("Enter the number of the text column: ")) - 1
        text_col = df.columns[choice]
    
    if category_col is None:
        print("\n🔍 Could not auto-detect category column")
        print("Available columns:")
        for i, col in enumerate(df.columns, 1):
            print(f"{i}. {col}")
        choice = int(input("Enter the number of the category column: ")) - 1
        category_col = df.columns[choice]
    
    print(f"\n✅ Using:")
    print(f"   Text column: '{text_col}'")
    print(f"   Category column: '{category_col}'")
    
    # Extract data
    texts = df[text_col].fillna("").apply(clean_text).tolist()
    categories = df[category_col].fillna("").astype(str).tolist()
    
    # Filter out empty texts
    valid_data = [(t, c) for t, c in zip(texts, categories) if t and len(t) > 10]
    
    print(f"\n📊 CSV Data Summary:")
    print(f"   Total rows: {len(df)}")
    print(f"   Valid rows: {len(valid_data)}")
    
    return valid_data

def load_builtin_data():
    """Load built-in training data from ml_model.py"""
    print("\n📚 Loading built-in training data...")
    
    # Convert Category enum to string
    builtin_data = [(text, cat.value) for text, cat in TRAINING_DATA]
    
    print(f"   Built-in samples: {len(builtin_data)}")
    
    # Show category distribution
    categories = {}
    for _, cat in builtin_data:
        categories[cat] = categories.get(cat, 0) + 1
    
    print("\n📊 Built-in Category Distribution:")
    for cat, count in categories.items():
        print(f"   {cat}: {count}")
    
    return builtin_data

def prepare_training_data(csv_data, builtin_data):
    """Combine CSV and built-in data"""
    print("\n" + "="*60)
    print("COMBINING DATASETS")
    print("="*60)
    
    # Combine data
    all_data = csv_data + builtin_data
    
    # Shuffle with seed for reproducibility
    import random
    random.seed(RANDOM_SEED)
    random.shuffle(all_data)
    
    # Split into texts and labels
    texts = [item[0] for item in all_data]
    labels = [item[1] for item in all_data]
    
    print(f"\n📊 Final Dataset:")
    print(f"   Total samples: {len(texts)}")
    
    # Show final category distribution
    from collections import Counter
    dist = Counter(labels)
    print("\n📈 Category Distribution:")
    for cat, count in sorted(dist.items()):
        percentage = (count / len(labels)) * 100
        print(f"   {cat}: {count} ({percentage:.1f}%)")
    
    return texts, labels

def train_model(texts, labels):
    """Train the model"""
    print("\n" + "="*60)
    print("TRAINING MODEL")
    print("="*60)
    
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report, accuracy_score
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.2, random_state=RANDOM_SEED, stratify=labels
    )
    
    print(f"\n📊 Data Split:")
    print(f"   Training: {len(X_train)} samples")
    print(f"   Testing: {len(X_test)} samples")
    
    # Create vectorizer
    print("\n🔄 Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        max_features=1000,
        ngram_range=(1, 2),
        stop_words='english',
        lowercase=True
    )
    
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    print(f"   Vocabulary size: {len(vectorizer.vocabulary_)}")
    
    # Train classifier
    print("\n🔄 Training Logistic Regression...")
    classifier = LogisticRegression(
        max_iter=1000,
        random_state=RANDOM_SEED,
        multi_class='multinomial',
        solver='lbfgs',
        C=1.0
    )
    
    classifier.fit(X_train_vec, y_train)
    
    # Evaluate
    y_pred = classifier.predict(X_test_vec)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\n✅ Test Accuracy: {accuracy:.2%}")
    
    print("\n📋 Classification Report:")
    print(classification_report(y_test, y_pred))
    
    return vectorizer, classifier

def save_model(vectorizer, classifier):
    """Save model and vectorizer"""
    print("\n💾 Saving model...")
    
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(classifier, f)
    
    with open(VECTORIZER_PATH, 'wb') as f:
        pickle.dump(vectorizer, f)
    
    print(f"✅ Model saved to: {MODEL_PATH}")
    print(f"✅ Vectorizer saved to: {VECTORIZER_PATH}")

def test_model(vectorizer, classifier):
    """Test the trained model"""
    print("\n" + "="*60)
    print("TESTING MODEL")
    print("="*60)
    
    test_queries = [
        "The database server is down, can't access anything",
        "I was charged twice for my subscription",
        "I forgot my password and can't login",
        "Where is my package? It's been 2 weeks",
        "The app crashes when I try to export",
        "Security issue with my account",
        "How do I upgrade my plan?",
        "API returning 500 errors"
    ]
    
    for query in test_queries:
        cleaned = clean_text(query)
        X_test = vectorizer.transform([cleaned])
        pred = classifier.predict(X_test)[0]
        proba = classifier.predict_proba(X_test).max()
        
        print(f"\n📝 Query: {query[:50]}...")
        print(f"   → Category: {pred}")
        print(f"   → Confidence: {proba:.2%}")

def main():
    print("="*70)
    print(" INTELLIGENT TICKET TRIAGE AGENT - CSV TRAINING")
    print("="*70)
    
    # Ask for CSV path
    csv_path = input("\n📁 Enter path to your CSV file: ").strip()
    
    if not Path(csv_path).exists():
        print(f"\n❌ File not found: {csv_path}")
        print("\nSearching for CSV files in Downloads...")
        
        from pathlib import Path
        downloads = Path.home() / "Downloads"
        csv_files = list(downloads.glob("*.csv"))
        
        if csv_files:
            print("\nFound CSV files:")
            for i, file in enumerate(csv_files, 1):
                print(f"{i}. {file.name}")
            
            choice = int(input("\nSelect file number: ")) - 1
            csv_path = str(csv_files[choice])
        else:
            print("❌ No CSV files found in Downloads")
            return
    
    try:
        # Load data from both sources
        csv_data = load_csv_data(csv_path)
        builtin_data = load_builtin_data()
        
        if len(csv_data) == 0:
            print("\n⚠️ No valid data found in CSV. Using only built-in data.")
            texts, labels = zip(*builtin_data) if builtin_data else ([], [])
        else:
            # Combine datasets
            texts, labels = prepare_training_data(csv_data, builtin_data)
        
        if len(texts) < 10:
            print("\n❌ Not enough data to train model. Need at least 10 samples.")
            return
        
        # Train model
        vectorizer, classifier = train_model(texts, labels)
        
        # Save model
        save_model(vectorizer, classifier)
        
        # Test model
        test_model(vectorizer, classifier)
        
        print("\n" + "="*70)
        print("✅ TRAINING COMPLETE!")
        print("="*70)
        print("\nRun the app with: streamlit run app.py")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
