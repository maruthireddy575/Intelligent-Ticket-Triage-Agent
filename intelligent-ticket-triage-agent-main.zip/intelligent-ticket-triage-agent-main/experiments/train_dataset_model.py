import pandas as pd
import pickle
from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.utils.class_weight import compute_class_weight
import numpy as np

print("Loading dataset...")

df = pd.read_csv("data/raw/customer_support_tickets.csv")

df["text"] = (
    df["Ticket Subject"].fillna("") + " " +
    df["Ticket Description"].fillna("")
).str.lower()


def map_category(text):

    if any(k in text for k in [
        "database","server","cluster","deployment",
        "connection","network","timeout","cannot connect",
        "service down","api down"
    ]):
        return "infrastructure"

    if any(k in text for k in [
        "refund","billing","payment","invoice","charge"
    ]):
        return "infrastructure"

    if any(k in text for k in [
        "feature","add","support","request","option",
        "export","ability","improvement"
    ]):
        return "feature_request"

    if any(k in text for k in [
        "error","bug","crash","failed","exception",
        "not working","broken"
    ]):
        return "bug"

    return "unclear"


df["label"] = df["text"].apply(map_category)
df = df[df["label"] != "unclear"]

# remove extremely small classes
counts = df["label"].value_counts()
valid_classes = counts[counts >= 20].index
df = df[df["label"].isin(valid_classes)]

X = df["text"]
y = df["label"]

print("Dataset size:", len(df))
print("Class distribution:\n", y.value_counts())

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("Vectorizing text...")

vectorizer = TfidfVectorizer(
    max_features=20000,
    ngram_range=(1,2),
    stop_words="english",
    min_df=2
)

X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

classes = np.unique(y_train)
weights = compute_class_weight("balanced", classes=classes, y=y_train)
class_weights = dict(zip(classes, weights))

print("Training model...")

model = LogisticRegression(
    max_iter=1500,
    class_weight=class_weights,
    n_jobs=-1
)

model.fit(X_train_vec, y_train)

preds = model.predict(X_test_vec)

print("\nAccuracy:", accuracy_score(y_test, preds))

print("\nClassification Report\n")
print(classification_report(y_test, preds, zero_division=0))

Path("models").mkdir(exist_ok=True)

with open("models/model.pkl", "wb") as f:
    pickle.dump(model, f)

with open("models/vectorizer.pkl", "wb") as f:
    pickle.dump(vectorizer, f)

print("\nModel saved to models/")