
"""
Corrected training script for Intelligent Ticket Triage Agent
Uses the correct columns from your CSV
"""

import pandas as pd
import numpy as np
import pickle
import re
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from collections import Counter

# Configuration
RANDOM_SEED = 42
TEST_SIZE = 0.2
MAX_FEATURES = 5000

# Paths
MODEL_PATH = Path("models/model.pkl")
VECTORIZER_PATH = Path("models/vectorizer.pkl")
MODEL_PATH.parent.mkdir(exist_ok=True)

def clean_text(text):
    """Clean and preprocess text"""
    if pd.isna(text) or not isinstance(text, str):
        return ""
    text = str(text).lower()
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"[^a-zA-Z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def main():
    print("="*70)
    print("CORRECTED TICKET TRIAGE MODEL TRAINING")
    print("="*70)
    
    # Load the CSV
    csv_path = Path("data/customer_support_tickets.csv")
    print(f"\n📂 Loading: {csv_path}")
    
    df = pd.read_csv(csv_path)
    print(f"📊 Loaded {len(df)} rows")
    print(f"\nColumns available:")
    for i, col in enumerate(df.columns, 1):
        print(f"{i}. {col}")
    
    # Use the correct columns
    text_col = 'Ticket Description'  # This contains the actual ticket text
    category_col = 'Ticket Type'      # This contains the category (Technical, Billing, etc.)
    
    print(f"\n✅ Using:")
    print(f"   Text column: '{text_col}'")
    print(f"   Category column: '{category_col}'")
    
    # Check unique categories
    unique_categories = df[category_col].unique()
    print(f"\n📊 Categories found: {list(unique_categories)}")
    
    # Extract and clean data
    texts = df[text_col].fillna("").astype(str).apply(clean_text).tolist()
    categories = df[category_col].fillna("").astype(str).tolist()
    
    # Filter out empty texts
    valid_data = [(t, c) for t, c in zip(texts, categories) if t and len(t) > 10]
    print(f"\n📊 Valid samples: {len(valid_data)} out of {len(df)}")
    
    if len(valid_data) < 100:
        print("❌ Not enough valid samples")
        return
    
    # Prepare data
    texts = [item[0] for item in valid_data]
    labels = [item[1] for item in valid_data]
    
    # Show category distribution
    dist = Counter(labels)
    print("\n📈 Category Distribution:")
    for category, count in sorted(dist.items(), key=lambda x: -x[1]):
        percentage = (count / len(labels)) * 100
        print(f"   {category}: {count} ({percentage:.1f}%)")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=labels
    )
    
    print(f"\n📊 Training set: {len(X_train)} samples")
    print(f"📊 Testing set: {len(X_test)} samples")
    
    # Create vectorizer
    print("\n🔄 Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        max_features=MAX_FEATURES,
        ngram_range=(1, 2),
        stop_words='english',
        lowercase=True,
        min_df=5,
        max_df=0.8
    )
    
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    print(f"   Vocabulary size: {len(vectorizer.vocabulary_)}")
    
    # Train classifier
    print("\n🔄 Training Logistic Regression classifier...")
    classifier = LogisticRegression(
        max_iter=2000,
        random_state=RANDOM_SEED,
        multi_class='multinomial',
        solver='lbfgs',
        C=1.0,
        class_weight='balanced',
        n_jobs=-1
    )
    
    classifier.fit(X_train_vec, y_train)
    
    # Evaluate
    y_pred = classifier.predict(X_test_vec)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\n✅ Test Accuracy: {accuracy:.2%}")
    
    # Detailed metrics
    print("\n📋 Classification Report:")
    print(classification_report(y_test, y_pred))
    
    # Save model
    print("\n💾 Saving model...")
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(classifier, f)
    
    with open(VECTORIZER_PATH, 'wb') as f:
        pickle.dump(vectorizer, f)
    
    print(f"✅ Model saved to: {MODEL_PATH}")
    print(f"✅ Vectorizer saved to: {VECTORIZER_PATH}")
    
    # Test with sample queries
    print("\n" + "="*70)
    print("TESTING MODEL WITH SAMPLE QUERIES")
    print("="*70)
    
    test_queries = [
        "I was charged twice for my subscription",
        "The app crashes when I try to login",
        "I forgot my password",
        "Where is my package?",
        "How do I use this feature?",
        "Security issue with my account",
    ]
    
    for query in test_queries:
        cleaned = clean_text(query)
        X_test = vectorizer.transform([cleaned])
        pred = classifier.predict(X_test)[0]
        probs = classifier.predict_proba(X_test)[0]
        confidence = max(probs)
        
        print(f"\n📝 Query: {query}")
        print(f"   → Predicted: {pred}")
        print(f"   → Confidence: {confidence:.2%}")
    
    print("\n" + "="*70)
    print("✅ TRAINING COMPLETE!")
    print("="*70)
    print("\n🚀 Run the app with: streamlit run app.py")

if __name__ == "__main__":
    main()
