# ✅ Pre-Deployment Checklist

Use this checklist to verify the system is ready for deployment.

## 🚀 System Installation

- [ ] Python 3.11+ installed
- [ ] pip package manager working
- [ ] Virtual environment created (optional but recommended)
- [ ] Dependencies installed: `pip install -r requirements.txt`

## 📁 Project Structure

- [ ] `src/` folder exists with 11 Python files
- [ ] `ui/` folder exists with 2 Python files
- [ ] `evaluation/` folder exists with Python + JSON files
- [ ] `models/` folder exists (can be empty)
- [ ] `database/` folder exists (can be empty)
- [ ] `app.py` file exists
- [ ] `config.json` file exists
- [ ] `requirements.txt` file exists

### File Count Verification

```
src/
├── __init__.py ✓
├── baseline.py ✓
├── config.py ✓
├── confidence.py ✓
├── logger.py ✓
├── metrics.py ✓
├── ml_model.py ✓
├── orchestrator.py ✓
├── risk_engine.py ✓
├── state_machine.py ✓
└── tools.py ✓

ui/
├── __init__.py ✓
├── components.py ✓
└── theme.py ✓

evaluation/
├── __init__.py ✓
├── evaluation.py ✓
└── scenarios.json ✓
```

## 📚 Documentation

- [ ] `PROJECT_SUMMARY.md` exists and readable
- [ ] `SETUP_GUIDE.md` exists and readable
- [ ] `ARCHITECTURE.md` exists and readable
- [ ] `QUICK_REFERENCE.md` exists and readable
- [ ] `INDEX.md` exists and readable
- [ ] `README.md` exists

## ⚙️ Configuration

- [ ] `config.json` has valid JSON syntax
- [ ] `config.json` contains all required keys:
  - [ ] `confidence_threshold`
  - [ ] `max_steps`
  - [ ] `seed`
  - [ ] `risk_weights` (with 4 components)

## 🎯 Application Startup

- [ ] Python can import all modules without errors:
  ```bash
  python -c "from src.orchestrator import TriageOrchestrator; print('✓ Core loaded')"
  python -c "from ui.components import render_state_timeline; print('✓ UI loaded')"
  python -c "from evaluation.evaluation import EvaluationHarness; print('✓ Eval loaded')"
  ```

- [ ] Streamlit app starts without errors:
  ```bash
  streamlit run app.py
  ```
  Expected: App opens at http://localhost:8501

## 🧪 Basic Functionality

In Streamlit UI:

- [ ] **Submit Tab loads**
  - [ ] Text input fields visible
  - [ ] Settings section visible
  - [ ] Analyze button clickable

- [ ] **Analytics Tab loads**
  - [ ] Displays "No runs available yet" or data

- [ ] **Evaluation Tab loads**
  - [ ] Radio buttons for test type
  - [ ] Run Evaluation button clickable

- [ ] **Logs Tab loads**
  - [ ] Shows setup section
  - [ ] Dropdown for run selection

## 🚀 Ticket Processing

- [ ] **Submit a test ticket:**
  - Subject: "Test ticket"
  - Description: "This is a test ticket for system verification"
  - Click "Analyze Ticket"

- [ ] **Results display correctly:**
  - [ ] Classification shown
  - [ ] Priority shown
  - [ ] Risk score shown
  - [ ] Confidence score shown
  - [ ] State timeline visible
  - [ ] Tool calls traced
  - [ ] Decision trace provided

- [ ] **Performance acceptable:**
  - [ ] Execution time < 1 second
  - [ ] UI responsive
  - [ ] No error messages

## 📊 Database & Logging

- [ ] **Database created:**
  - When first ticket processed, `database/runs.db` should exist

- [ ] **Logging works:**
  - [ ] Can view run in Logs tab
  - [ ] State transitions logged
  - [ ] Tool calls logged

- [ ] **JSONL backup created:**
  - When first ticket processed, `database/runs.jsonl` should exist

## 🧠 ML Model

- [ ] **Model training:**
  - [ ] On first run, model trains automatically
  - [ ] `models/model.pkl` created
  - [ ] `models/vectorizer.pkl` created

- [ ] **Model inference:**
  - [ ] Predictions generated
  - [ ] Confidence scores provided
  - [ ] Probabilities for all categories

## 🧪 Evaluation System

- [ ] **Run evaluation:**
  1. Go to Evaluation tab
  2. Select "Run All Scenarios"
  3. Click "Run Evaluation"
  
  - [ ] Completes without errors
  - [ ] Shows metrics dashboard
  - [ ] Displays classification/priority/end-to-end accuracy
  - [ ] Shows confusion matrix option

- [ ] **Baseline comparison:**
  1. Go to Evaluation tab
  2. Select "Compare Models"
  3. Click "Run Evaluation"
  
  - [ ] Completes successfully
  - [ ] Shows ML vs Baseline comparison
  - [ ] ML accuracy > Baseline accuracy

## 📊 Analytics

- [ ] **Analytics dashboard:**
  1. Go to Analytics tab
  2. After submitting tickets
  
  - [ ] Recent runs table populated
  - [ ] Metrics displayed
  - [ ] Charts rendered

## 🔍 Logs & Observability

- [ ] **View logs:**
  1. Go to Logs tab
  2. Select a run from dropdown
  3. View each log type:
  
  - [ ] Summary tab works
  - [ ] State Transitions tab works
  - [ ] Tool Calls tab works
  - [ ] Events tab works

## 🎨 UI/UX

- [ ] **Visual Design:**
  - [ ] Colors consistent
  - [ ] Layout responsive
  - [ ] Buttons clickable
  - [ ] Text readable

- [ ] **Animations & Transitions:**
  - [ ] Hover effects work
  - [ ] Smooth transitions visible
  - [ ] No jarring animations

- [ ] **Charts & Visualization:**
  - [ ] Plotly charts render
  - [ ] Interactive features work
  - [ ] Responsive to window resize

## 🔒 Safety & Validation

- [ ] **Input validation:**
  - [ ] Very short subject rejected
  - [ ] Very long subject truncated
  - [ ] Empty description rejected
  - [ ] Error messages clear

- [ ] **State machine:**
  - [ ] No invalid state transitions
  - [ ] History complete
  - [ ] Transitions logged

- [ ] **Error handling:**
  - [ ] Graceful error messages
  - [ ] No unhandled exceptions
  - [ ] Database errors recoverable

## 📈 Performance

- [ ] **Processing speed:**
  - [ ] Single ticket: <100ms (typically 50-80ms)
  - [ ] First run: ~2 seconds (model training)
  - [ ] UI responsive (<500ms interactions)

- [ ] **Resource usage:**
  - [ ] Memory steady (not growing)
  - [ ] CPU minimal when idle
  - [ ] Disk usage reasonable (<100MB)

## 🔧 Configuration Changes

After verifying basic functionality, test configuration:

- [ ] **Change confidence_threshold to 0.5:**
  1. Edit `config.json`
  2. Run app again
  3. More tickets should escalate
  4. Verify in Logs tab

- [ ] **Change random seed to 123:**
  1. Edit `config.json`
  2. Retrain model: `python -c "from src.ml_model import MLModel; MLModel().train()"`
  3. Run app again
  4. Execute same ticket again
  5. Should get same results

## 🎓 Demo Readiness

For internship/interview presentation:

- [ ] System starts cleanly
- [ ] UI looks professional
- [ ] Demo ticket processes < 1 second
- [ ] Results display clearly
- [ ] Can explain state machine
- [ ] Can explain risk scoring
- [ ] Can explain ML model
- [ ] Can navigate all tabs
- [ ] Evaluation runs successfully
- [ ] Logs display clearly

## 📝 Documentation Check

- [ ] All `.md` files present
- [ ] No broken links in docs
- [ ] Code examples accurate
- [ ] Installation instructions clear
- [ ] Architecture diagrams present
- [ ] Quick reference helpful

## 🚨 Troubleshooting Verification

Test each resolution from QUICK_REFERENCE.md:

- [ ] Missing model: Auto-trains on first run ✓
- [ ] Slow processing: Check if first run ✓
- [ ] Database errors: Delete runs.db works ✓
- [ ] UI not updating: Page refresh works ✓

## 📊 Final Verification

Run this Python script to verify all components:

```python
#!/usr/bin/env python3
"""Verification script for Intelligent Ticket Triage Agent"""

import sys
from pathlib import Path

def verify():
    print("Verifying Intelligent Ticket Triage Agent...")
    print()
    
    errors = []
    
    # Check Python version
    if sys.version_info < (3, 11):
        errors.append("Python 3.11+ required")
    else:
        print("✓ Python version OK")
    
    # Check imports
    try:
        from src.orchestrator import TriageOrchestrator
        from src.state_machine import StateMachine
        from src.ml_model import get_model
        from evaluation.evaluation import EvaluationHarness
        print("✓ All imports successful")
    except ImportError as e:
        errors.append(f"Import error: {e}")
    
    # Check files
    required_files = [
        "app.py",
        "config.json",
        "requirements.txt",
        "src/state_machine.py",
        "src/ml_model.py",
        "evaluation/scenarios.json",
    ]
    
    for file in required_files:
        if Path(file).exists():
            print(f"✓ {file}")
        else:
            errors.append(f"Missing: {file}")
    
    # Check configuration
    try:
        import json
        with open("config.json") as f:
            config = json.load(f)
        if all(k in config for k in ["confidence_threshold", "max_steps", "seed"]):
            print("✓ Configuration valid")
        else:
            errors.append("Configuration missing required keys")
    except Exception as e:
        errors.append(f"Configuration error: {e}")
    
    print()
    if errors:
        print("❌ Issues found:")
        for error in errors:
            print(f"  - {error}")
        return False
    else:
        print("✅ All checks passed! System ready for deployment.")
        return True

if __name__ == "__main__":
    success = verify()
    sys.exit(0 if success else 1)
```

Save as `verify.py` and run:
```bash
python verify.py
```

Expected output: `✅ All checks passed! System ready for deployment.`

## ✅ Sign-Off

- [ ] All checks completed
- [ ] No errors found
- [ ] System tested and working
- [ ] Documentation verified
- [ ] Ready for presentation
- [ ] Ready for production

**Status**: Ready to Deploy ✅

---

**Checklist Version**: 1.0
**Last Updated**: February 27, 2026
