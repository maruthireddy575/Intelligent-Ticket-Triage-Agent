"""
Train ML Model with Real Customer Support Dataset
"""

import pandas as pd
import numpy as np
import pickle
import re
import os
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# Configuration
RANDOM_SEED = 42
TEST_SIZE = 0.2
MAX_FEATURES = 5000

# Paths
MODEL_PATH = Path("models/model.pkl")
VECTORIZER_PATH = Path("models/vectorizer.pkl")
MODEL_PATH.parent.mkdir(exist_ok=True)

# Category mapping (map your dataset categories to the 5 required categories)
CATEGORY_MAPPING = {
    # Billing related
    'billing': 'Billing',
    'payment': 'Billing',
    'invoice': 'Billing',
    'charge': 'Billing',
    'refund': 'Billing',
    'subscription': 'Billing',
    'price': 'Billing',
    'cost': 'Billing',
    'money': 'Billing',
    
    # Technical related
    'technical': 'Technical',
    'bug': 'Technical',
    'error': 'Technical',
    'crash': 'Technical',
    'not working': 'Technical',
    'broken': 'Technical',
    'issue': 'Technical',
    'problem': 'Technical',
    'fail': 'Technical',
    'glitch': 'Technical',
    
    # Delivery related
    'delivery': 'Delivery',
    'shipping': 'Delivery',
    'shipment': 'Delivery',
    'tracking': 'Delivery',
    'arrived': 'Delivery',
    'late': 'Delivery',
    'order': 'Delivery',
    'package': 'Delivery',
    
    # Account related
    'account': 'Account',
    'login': 'Account',
    'password': 'Account',
    'sign in': 'Account',
    'access': 'Account',
    'profile': 'Account',
    'register': 'Account',
    'username': 'Account',
    'authentication': 'Account',
    
    # If nothing matches, it's General
}

def clean_text(text):
    """Clean and preprocess text"""
    if pd.isna(text) or not isinstance(text, str):
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Remove special characters and digits
    text = re.sub(r'[^a-zA-Z\s]', ' ', text)
    
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text

def map_category(text):
    """Map text to one of the 5 categories based on keywords"""
    text_lower = text.lower()
    
    for keyword, category in CATEGORY_MAPPING.items():
        if keyword in text_lower:
            return category
    
    return 'General'  # Default category

def find_csv_file():
    """Find the customer support CSV file"""
    # Common locations
    possible_paths = [
        "customer_support_tickets.csv",
        "support_tickets.csv",
        "tickets.csv",
        "customer-support-tickets.csv",
        "Customer Support Ticket.csv",
        "customer support ticket.csv",
        "../customer_support_tickets.csv",
        "../../customer_support_tickets.csv",
        "~/Downloads/customer_support_tickets.csv",
        "~/Downloads/Customer Support Ticket.csv",
    ]
    
    # Also search in Downloads folder
    downloads_path = Path.home() / "Downloads"
    if downloads_path.exists():
        for file in downloads_path.glob("*.csv"):
            if "customer" in file.name.lower() or "support" in file.name.lower() or "ticket" in file.name.lower():
                return file
    
    # Check possible paths
    for path in possible_paths:
        expanded_path = Path(path).expanduser()
        if expanded_path.exists():
            return expanded_path
    
    return None

def load_and_prepare_data(filepath):
    """Load CSV and prepare for training"""
    print(f"\n📂 Loading data from: {filepath}")
    print("-" * 50)
    
    # Try different encodings
    encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252']
    df = None
    
    for encoding in encodings:
        try:
            df = pd.read_csv(filepath, encoding=encoding, nrows=5)  # Test with first 5 rows
            print(f"✓ Successfully read with encoding: {encoding}")
            df = pd.read_csv(filepath, encoding=encoding)
            break
        except:
            continue
    
    if df is None:
        raise Exception("Could not read CSV file with any encoding")
    
    print(f"\n📊 Dataset Info:")
    print(f"   Total rows: {len(df)}")
    print(f"   Columns: {list(df.columns)}")
    
    # Display first few rows to understand structure
    print("\n👀 First 3 rows:")
    print(df.head(3).to_string())
    
    # Try to identify text and category columns
    text_col = None
    category_col = None
    
    # Common column names for text
    text_keywords = ['text', 'description', 'body', 'content', 'message', 'ticket', 'issue', 'problem']
    # Common column names for category
    category_keywords = ['category', 'type', 'class', 'label', 'department', 'group', 'topic']
    
    for col in df.columns:
        col_lower = col.lower()
        for keyword in text_keywords:
            if keyword in col_lower:
                text_col = col
                break
        for keyword in category_keywords:
            if keyword in col_lower:
                category_col = col
                break
    
    # If still not found, ask user
    if text_col is None or category_col is None:
        print("\n" + "="*50)
        print("COLUMN IDENTIFICATION NEEDED")
        print("="*50)
        print("\nAvailable columns:")
        for i, col in enumerate(df.columns, 1):
            print(f"{i}. {col}")
        
        if text_col is None:
            text_idx = input("\nEnter the number of the column containing the ticket text/description: ")
            text_col = df.columns[int(text_idx) - 1]
        
        if category_col is None:
            cat_idx = input("Enter the number of the column containing the category: ")
            category_col = df.columns[int(cat_idx) - 1]
    
    print(f"\n✅ Using:")
    print(f"   Text column: '{text_col}'")
    print(f"   Category column: '{category_col}'")
    
    # Remove rows with missing values
    df = df.dropna(subset=[text_col, category_col])
    print(f"\n   After removing missing values: {len(df)} rows")
    
    # Clean text
    print("   Cleaning text...")
    df['clean_text'] = df[text_col].apply(clean_text)
    
    # Map categories
    print("   Mapping categories to standard 5 categories...")
    df['standard_category'] = df[category_col].apply(map_category)
    
    # Show category distribution
    print("\n📊 Category Distribution:")
    category_counts = df['standard_category'].value_counts()
    for cat, count in category_counts.items():
        percentage = (count / len(df)) * 100
        print(f"   {cat}: {count} ({percentage:.1f}%)")
    
    return df['clean_text'], df['standard_category']

def train_model(X, y):
    """Train TF-IDF + Logistic Regression model"""
    print("\n" + "="*60)
    print("TRAINING MODEL")
    print("="*60)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_SEED, stratify=y
    )
    
    print(f"\n📊 Data Split:")
    print(f"   Training samples: {len(X_train)}")
    print(f"   Testing samples: {len(X_test)}")
    print(f"   Categories: {y.unique().tolist()}")
    
    # Create TF-IDF vectorizer
    print("\n🔄 Creating TF-IDF vectorizer...")
    vectorizer = TfidfVectorizer(
        max_features=MAX_FEATURES,
        ngram_range=(1, 2),
        stop_words='english',
        lowercase=True
    )
    
    # Transform text
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)
    
    print(f"   Vocabulary size: {len(vectorizer.vocabulary_)}")
    print(f"   Training matrix shape: {X_train_vec.shape}")
    
    # Train classifier
    print("\n🔄 Training Logistic Regression classifier...")
    classifier = LogisticRegression(
        max_iter=1000,
        random_state=RANDOM_SEED,
        multi_class='multinomial',
        solver='lbfgs',
        C=1.0,
        class_weight='balanced'
    )
    
    classifier.fit(X_train_vec, y_train)
    
    # Evaluate
    print("\n📊 Evaluating model...")
    y_pred = classifier.predict(X_test_vec)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\n✅ Test Accuracy: {accuracy:.2%}")
    
    # Detailed metrics
    print("\n📋 Classification Report:")
    print(classification_report(y_test, y_pred))
    
    # Confusion Matrix
    plt.figure(figsize=(10, 8))
    cm = confusion_matrix(y_test, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=classifier.classes_,
                yticklabels=classifier.classes_)
    plt.title('Confusion Matrix - Ticket Classification')
    plt.xlabel('Predicted Category')
    plt.ylabel('Actual Category')
    plt.tight_layout()
    plt.savefig('models/confusion_matrix.png')
    plt.show()
    
    return vectorizer, classifier, accuracy

def save_model(vectorizer, classifier):
    """Save model and vectorizer"""
    print("\n💾 Saving model...")
    
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(classifier, f)
    
    with open(VECTORIZER_PATH, 'wb') as f:
        pickle.dump(vectorizer, f)
    
    print(f"✓ Model saved to: {MODEL_PATH}")
    print(f"✓ Vectorizer saved to: {VECTORIZER_PATH}")

def test_model(vectorizer, classifier):
    """Test model with sample queries"""
    print("\n" + "="*60)
    print("TESTING MODEL WITH SAMPLE QUERIES")
    print("="*60)
    
    test_queries = [
        "I was charged twice for my subscription",
        "The app keeps crashing when I try to login",
        "My package hasn't arrived yet",
        "I forgot my password",
        "How do I use this feature?",
        "Security issue with my account",
        "Where is my order?",
        "Can't connect to the server",
    ]
    
    for query in test_queries:
        cleaned = clean_text(query)
        X_test = vectorizer.transform([cleaned])
        pred = classifier.predict(X_test)[0]
        proba = classifier.predict_proba(X_test).max()
        
        print(f"\n📝 Query: {query}")
        print(f"   📌 Category: {pred}")
        print(f"   📊 Confidence: {proba:.2%}")

def main():
    print("="*70)
    print(" INTELLIGENT TICKET TRIAGE AGENT - REAL DATA TRAINING")
    print("="*70)
    
    # Find CSV file
    csv_file = find_csv_file()
    
    if csv_file is None:
        print("\n❌ Could not find customer support CSV file!")
        print("\nPlease provide the path to your CSV file:")
        file_path = input("CSV file path: ").strip()
        
        if not Path(file_path).exists():
            print(f"\n❌ File not found: {file_path}")
            return
        csv_file = Path(file_path)
    
    try:
        # Load and prepare data
        X, y = load_and_prepare_data(csv_file)
        
        if len(X) < 10:
            print("\n❌ Not enough data to train model. Need at least 10 samples.")
            return
        
        # Train model
        vectorizer, classifier, accuracy = train_model(X, y)
        
        # Save model
        save_model(vectorizer, classifier)
        
        # Test model
        test_model(vectorizer, classifier)
        
        print("\n" + "="*70)
        print("✅ TRAINING COMPLETE!")
        print("="*70)
        print("\nYou can now run the app with:")
        print("   streamlit run app.py")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
