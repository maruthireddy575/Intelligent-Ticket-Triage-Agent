# Quick Reference Guide

## 🚀 Getting Started (2 minutes)

```bash
# 1. Install
pip install -r requirements.txt

# 2. Run
streamlit run app.py

# 3. Visit
http://localhost:8501
```

## 📋 Main Use Cases

### Use Case 1: Analyze a Ticket

1. Click **Submit Ticket** tab
2. Enter subject and description
3. Click **Analyze Ticket**
4. View results with decision trace

**Output includes:**
- Category (Bug, Security, Infrastructure, etc.)
- Priority (Low, Medium, High)
- Risk score with breakdown
- Confidence level
- Full state machine timeline
- Tool execution trace

### Use Case 2: View System Performance

1. Click **Analytics Dashboard** tab
2. See recent runs and trends
3. View escalation statistics
4. Check average confidence/risk

### Use Case 3: Evaluate System

1. Click **Evaluation Harness** tab
2. Select "Run All Scenarios"
3. Click **Run Evaluation**
4. Compare ML model vs baseline
5. View accuracy metrics

### Use Case 4: Inspect Logs

1. Click **Logs & Observability** tab
2. Select a run from dropdown
3. Choose log type:
   - **Summary**: Overview of the run
   - **State Transitions**: FSM history
   - **Tool Calls**: All tool executions
   - **Events**: Processing events

## ⚙️ Configuration

Edit `config.json` to tune:

```json
{
  "confidence_threshold": 0.75,   // ← Adjust escalation sensitivity
  "max_steps": 20,                // ← Max state transitions
  "seed": 42,                     // ← For reproducibility
  "risk_weights": {
    "category_base": 0.3,         // ← Category importance
    "urgency_keyword": 0.25,      // ← Urgency importance
    "sentiment_negativity": 0.25, // ← Sentiment importance
    "uncertainty": 0.2            // ← Uncertainty importance
  }
}
```

## 🎫 Ticket Categories

| Category | Typical Issues |
|----------|---|
| **Bug** | Crashes, errors, broken features |
| **Security** | Vulnerabilities, authentication issues |
| **Infrastructure** | Servers, databases, scalability |
| **Performance** | Speed, optimization, latency |
| **Feature Request** | New capabilities, enhancements |
| **Documentation** | Clarity, examples, guides |
| **Unclear** | Vague or incomplete tickets |

## 📊 Priority Levels

- **🟢 LOW**: Risk 0.0–0.4 (e.g., typos, nice-to-haves)
- **🟡 MEDIUM**: Risk 0.4–0.7 (e.g., localized bugs, moderate impact)
- **🔴 HIGH**: Risk 0.7–1.0 (e.g., crashes, security issues, outages)

## 🧠 Risk Score Factors

1. **Category Base** (30%)
   - Security: 0.9 (highest)
   - Infrastructure: 0.7
   - Bug: 0.6
   - Performance: 0.5
   - Feature: 0.2
   - Documentation: 0.1

2. **Urgency Keywords** (25%)
   - Matches: "critical", "urgent", "asap", "emergency"
   - Score: 0–0.15 depending on keywords

3. **Sentiment** (25%)
   - Negative sentiment increases risk
   - Score: 0–1

4. **Uncertainty** (20%)
   - Short text: higher uncertainty
   - Vague terms: higher uncertainty
   - Questions: higher uncertainty
   - Score: 0–1

**Final Risk = All factors normalized to [0, 1]**

## 📈 Metrics Explained

### Classification Accuracy
- % of tickets correctly categorized
- Compare: ML ~86% vs Baseline ~65%

### Priority Accuracy
- % of priorities correctly assigned
- Compare: ML ~83% vs Baseline ~70%

### End-to-End Accuracy
- % correct category AND priority
- Compare: ML ~78% vs Baseline ~58%

### Escalation Rate
- % of tickets requiring escalation
- Indicates confidence in predictions

## 🔍 Understanding Results

### ✅ Completed (No Escalation)
- Confidence ≥ threshold (default 0.75)
- Medium risk (not critical)
- Routine processing

### ⚠️ Escalated
- Confidence < threshold
- Very high risk (>0.9)
- High risk + uncertain
- Needs human review

### ❌ Error
- Input validation failed
- Processing error occurred
- System error
- Check logs for details

## 💡 Demo Scenarios

### Scenario 1: Critical Bug
**Subject**: System crash on startup
**Description**: Application crashes immediately with error code 0x80004005 on all machines.

**Expected**: Bug category, High priority, Escalated

### Scenario 2: Security Issue
**Subject**: SQL injection vulnerability found
**Description**: Input not sanitized in login form, potential SQL injection.

**Expected**: Security category, High priority, Escalated

### Scenario 3: Feature Request
**Subject**: Add dark mode support
**Description**: Users requesting dark theme capability.

**Expected**: Feature Request category, Low priority, Completed

### Scenario 4: Infrastructure
**Subject**: Database server down
**Description**: CRITICAL: Database offline, all services affected, system outage.

**Expected**: Infrastructure category, High priority, Escalated

## 🛠️ Troubleshooting

| Issue | Fix |
|-------|-----|
| Model not found | First run trains model automatically |
| Slow processing | Check system resources, restart app |
| Database errors | Delete `database/runs.db`, restart |
| UI not updating | Refresh browser page, Ctrl+R |
| Can't submit ticket | Check minimum length (10 chars description) |

## 📊 Database Queries

### View Recent Runs (Python)
```python
from src.logger import TriageLogger

logger = TriageLogger()
runs = logger.get_all_runs(limit=10)

for run in runs:
    print(f"{run['subject']}: {run['predicted_category']} ({run['predicted_priority']})")
```

### Get Run Details
```python
run = logger.get_run("run_id_123")
transitions = logger.get_run_state_transitions("run_id_123")
tool_calls = logger.get_run_tool_calls("run_id_123")
```

## 🎓 Key Concepts

### State Machine
Explicit workflow with 11 states ensuring deterministic processing

### Tool Layer
Pure functions with validated inputs/outputs for auditability

### Risk Scoring
Multi-factor calculation combining category, urgency, sentiment, uncertainty

### Escalation
Automatic escalation for high risk or low confidence predictions

### Observability
Complete audit trail in SQLite + JSONL backup

## 📈 Performance Tips

1. **First run**: ~2 seconds (model training)
2. **Subsequent**: <100ms per ticket
3. **Database**: Creates on first run
4. **Caching**: Streamlit caches model automatically

## 🔒 Safety Features

✅ Input validation (min 10 chars, max 5000 chars)
✅ State machine prevents invalid transitions
✅ Confidence checks prevent unreliable escalations
✅ Manual override for special cases
✅ Full audit trail for compliance
✅ Error handling and recovery

## 📞 Support

Check logs for detailed execution trace:
1. Go to Logs & Observability tab
2. Select your run
3. View state transitions, tool calls, events
4. See exact timing and outputs

---

**Version**: 1.0.0 | **Last Updated**: Feb 27, 2026
