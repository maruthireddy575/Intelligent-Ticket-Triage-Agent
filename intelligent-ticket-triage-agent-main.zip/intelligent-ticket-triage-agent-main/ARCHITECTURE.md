# Architecture Document - Intelligent Ticket Triage Agent

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    STREAMLIT WEB UI (app.py)                   │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐ │
│  │ Submit Tab   │ Analytics    │ Evaluation   │ Logs Tab     │ │
│  │ - Form       │ - Dashboard  │ - Scenarios  │ - Trace View │ │
│  │ - Results    │ - Charts     │ - Metrics    │ - Events     │ │
│  │ - Timeline   │ - Filters    │ - Compare    │ - Raw JSON   │ │
│  └──────────────┴──────────────┴──────────────┴──────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│                      ORCHESTRATOR (orchestrator.py)             │
│  - Coordinates workflow                                         │
│  - Manages state transitions                                    │
│  - Calls tools in sequence                                      │
│  - Tracks execution timing                                      │
├─────────────────────────────────────────────────────────────────┤
│  STATE MACHINE  │  ML CLASSIFIER  │  RISK ENGINE  │  CONFIG    │
│  - FSM logic    │  - Inference    │  - Scoring    │  - Params  │
│  - Transitions  │  - Confidence   │  - Breakdown  │  - Limits  │
│  - History      │  - Probabilities│  - Weights    │  - Seed    │
├─────────────────────────────────────────────────────────────────┤
│  CONFIDENCE     │  LOGGER         │  BASELINE     │  METRICS   │
│  ENGINE         │  - SQLite       │  CLASSIFIER   │  - Accuracy│
│  - Scoring      │  - JSONL        │  - Rules      │  - Rates   │
│  - Escalation   │  - Audit trail  │  - Keywords   │  - Charts  │
├─────────────────────────────────────────────────────────────────┤
│                    DATA STORAGE & ARTIFACTS                     │
│  ┌─────────────────┬────────────────┬──────────────────────────┐ │
│  │ Database        │ Models         │ Configuration            │ │
│  │ - runs.db       │ - model.pkl    │ - config.json            │ │
│  │ - runs.jsonl    │ - vectorizer.  │ - scenarios.json         │ │
│  │ 4 tables        │   pkl          │                          │ │
│  └─────────────────┴────────────────┴──────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Module Descriptions

### 1. Core Workflow (`src/orchestrator.py`)

**Responsibilities:**
- Manages the complete ticket processing workflow
- Orchestrates state machine transitions
- Invokes tools in the correct sequence
- Tracks execution timing and metrics
- Coordinates error handling

**Key Methods:**
- `process_ticket()` - Main workflow entry point
- `_classify_ticket()` - Calls ML model
- `_compute_risk_score()` - Calculates risk
- `_assign_priority()` - Determines priority
- `_check_confidence()` - Decides escalation

**Data Flow:**
```
Ticket Input
   ↓
Validation
   ↓
Classification
   ↓
Risk Scoring
   ↓
Priority Assignment
   ↓
Confidence Check
   ↓
Decision (Complete/Escalate)
```

### 2. State Machine (`src/state_machine.py`)

**States (11 total):**
- IDLE (initial)
- TICKET_RECEIVED
- VALIDATING_INPUT
- CLASSIFYING
- RISK_SCORING
- PRIORITY_ASSIGNMENT
- CONFIDENCE_CHECK
- ESCALATED
- COMPLETED (terminal)
- NEED_MORE_INFO (terminal)
- ERROR (terminal)

**Events (11 total):**
- TICKET_SUBMITTED
- VALIDATION_PASSED / VALIDATION_FAILED
- CLASSIFICATION_COMPLETE
- RISK_CALCULATED
- PRIORITY_ASSIGNED
- CONFIDENCE_HIGH / CONFIDENCE_LOW
- ESCALATION_TRIGGERED
- PROCESSING_COMPLETE
- ERROR_OCCURRED

**Design Pattern:**
- Explicit FSM (no implicit states)
- Validated transitions (only allowed edges)
- Immutable transition history
- Timestamp every transition

### 3. ML Model (`src/ml_model.py`)

**Architecture:**
```
Raw Text
   ↓
TF-IDF Vectorizer
   ├─ Max Features: 500
   ├─ N-grams: (1, 2)
   ├─ Lowercase: True
   └─ Stop words: English
   ↓
Logistic Regression
   ├─ Solver: lbfgs
   ├─ Multi-class: multinomial
   ├─ Random state: 42
   └─ Max iterations: 200
   ↓
Prediction + Probabilities
```

**Training Data:**
- 60+ examples total
- Balanced across 7 categories
- Deterministic split (seed=42)
- Reproducible every run

**Artifacts:**
- `model.pkl` - Trained classifier
- `vectorizer.pkl` - TF-IDF transformer

**Performance:**
- Inference: ~20-50ms
- Training: <100ms (if needed)
- Binary determinism: Yes (same seed → same output)

### 4. Risk Engine (`src/risk_engine.py`)

**Risk Formula:**
```
risk_score = SUM(components × weights) / NORMALIZATION

Components:
1. Category Base (weight: 0.30)
   - Bug: 0.6, Security: 0.9, Infrastructure: 0.7
   - Performance: 0.5, Feature: 0.2, Documentation: 0.1

2. Urgency Keywords (weight: 0.25)
   - Matches: "critical", "urgent", "asap", "emergency", etc.
   - Score: 0.0 – 0.15 based on keyword

3. Sentiment Negativity (weight: 0.25)
   - Input: sentiment_score [-1, 1]
   - Extraction: max(0, -sentiment)
   - Range: [0, 1]

4. Uncertainty (weight: 0.20)
   - Short text (<50 chars): +0.3
   - Vague terms: +0.1 per term
   - Question marks: +0.1 each
   - Range: [0, 1]

Final Score: Clamped to [0, 1]
```

**Priority Mapping:**
```
[0.0 – 0.4) → LOW
[0.4 – 0.7) → MEDIUM
[0.7 – 1.0] → HIGH
```

### 5. Confidence Engine (`src/confidence.py`)

**Confidence Score Calculation:**
```
confidence = (classification_confidence × 0.6)
           + (risk_consistency × 0.25)
           + ((1 - category_diversity) × 0.15)

Where:
- classification_confidence = ML model probability
- risk_consistency = 1 - |risk_score - 0.5| / 0.5
- category_diversity = spread of probabilities
```

**Escalation Logic:**
```
if confidence < threshold:
    escalate = TRUE
    reason = "Low confidence"

elif risk_score >= 0.9:
    escalate = TRUE
    reason = "Critical risk"

elif risk_score >= 0.85 AND confidence < 0.8:
    escalate = TRUE
    reason = "High risk + moderate confidence"

else:
    escalate = FALSE
    reason = "Routine processing"
```

### 6. Logging System (`src/logger.py`)

**SQLite Schema:**

```sql
-- Main run records
CREATE TABLE runs (
    id TEXT PRIMARY KEY,
    timestamp TEXT,
    subject TEXT,
    description TEXT,
    predicted_category TEXT,
    predicted_priority TEXT,
    confidence REAL,
    risk_score REAL,
    escalated BOOLEAN,
    execution_time_ms REAL,
    status TEXT
);

-- Events during processing
CREATE TABLE events (
    id INTEGER PRIMARY KEY,
    run_id TEXT,
    event_type TEXT,
    timestamp TEXT,
    data TEXT (JSON),
    FOREIGN KEY (run_id) REFERENCES runs(id)
);

-- Tool execution traces
CREATE TABLE tool_calls (
    id INTEGER PRIMARY KEY,
    run_id TEXT,
    tool_name TEXT,
    input_data TEXT (JSON),
    output_data TEXT (JSON),
    execution_time_ms REAL,
    timestamp TEXT,
    FOREIGN KEY (run_id) REFERENCES runs(id)
);

-- State machine transitions
CREATE TABLE state_transitions (
    id INTEGER PRIMARY KEY,
    run_id TEXT,
    previous_state TEXT,
    event TEXT,
    next_state TEXT,
    timestamp TEXT,
    metadata TEXT (JSON),
    FOREIGN KEY (run_id) REFERENCES runs(id)
);
```

**JSONL Backup:**
- One JSON object per line
- Same data as SQLite
- Format: `type`, `run_id`, timestamp, data

**Thread Safety:**
- Mutex lock per operation
- Safe concurrent writes

### 7. Evaluation System (`evaluation/evaluation.py`)

**Test Scenarios (12 total):**
1. Critical crash - Expected: Bug, High
2. SQL injection - Expected: Security, High
3. Slow queries - Expected: Performance, Medium
4. Feature request - Expected: Feature, Low
5. Unclear docs - Expected: Documentation, Low
6. Database down - Expected: Infrastructure, High
7. Vague issue - Expected: Unclear, Low
8. Email failures - Expected: Bug, Medium
9. Urgent scaling - Expected: Infrastructure, High
10. Minor typo - Expected: Documentation, Low
11. Mobile login - Expected: Bug, High
12. Dark mode - Expected: Feature, Low

**Evaluation Process:**
```python
For each scenario:
    1. Classify with ML model
    2. Assign priority
    3. Compare to expected
    4. Record metrics
    
Metrics computed:
- Classification accuracy
- Priority accuracy
- End-to-end accuracy
- Escalation rate
- Per-category breakdown
```

**Baseline Comparison:**
- Keyword-based classifier
- Rule-based priority
- No ML training
- ~60-70% accuracy

### 8. Configuration (`src/config.py`)

**Parameters:**
```json
{
  "confidence_threshold": 0.75,      // Escalation cutoff
  "max_steps": 20,                   // Max FSM iterations
  "seed": 42,                        // Random seed
  "risk_weights": {
    "category_base": 0.3,
    "urgency_keyword": 0.25,
    "sentiment_negativity": 0.25,
    "uncertainty": 0.2
  }
}
```

**Load Order:**
1. Default hardcoded values
2. Override from config.json if exists
3. Override from environment if needed
4. Global singleton instance

### 9. Tool Layer (`src/tools.py`)

**Tool Execution Pattern:**
```python
# 1. Define Input Model (Pydantic)
class ToolInput(BaseModel):
    field1: str
    field2: int

# 2. Define Output Model (Pydantic)
class ToolOutput(BaseModel):
    result: str
    execution_time_ms: float

# 3. Execute Tool
def tool_func(input_model: ToolInput) -> ToolOutput:
    start = time.time()
    result = "..."
    execution_time = (time.time() - start) * 1000
    return ToolOutput(
        result=result,
        execution_time_ms=execution_time
    )

# 4. Record Tool Call
tool_call = ToolCall(
    tool_name="tool_func",
    input_model=input_model,
    output_model=output_model,
    execution_time_ms=execution_time
)
```

**Benefits:**
- Type safety (Pydantic validation)
- Structured I/O (easy serialization)
- Traceability (execution time)
- Auditability (full record)

## Data Flow Example

```
┌─ USER INPUT ─┐
│ Subject      │
│ Description  │
└──────────────┘
       │
       ↓
┌────────────────────────────────────┐
│ ORCHESTRATOR.process_ticket()      │
└────────────────────────────────────┘
       │
       ├─→ Validation
       │    INPUT: subject, description
       │    OUTPUT: valid ✓/✗
       │
       ├─→ State Transition
       │    IDLE → TICKET_RECEIVED → VALIDATING_INPUT
       │
       ├─→ ML Classification
       │    INPUT: "subject description"
       │    OUTPUT: category, confidence, probs
       │
       ├─→ Risk Scoring
       │    INPUT: category, description
       │    OUTPUT: risk_score, components
       │
       ├─→ Priority Assignment
       │    INPUT: category, risk_score
       │    OUTPUT: priority
       │
       ├─→ Confidence Check
       │    INPUT: classification_conf, risk_score
       │    OUTPUT: should_escalate, confidence
       │
       ├─→ Decision
       │    IF escalate: ESCALATED
       │    ELSE: COMPLETED
       │
       ├─→ Logging
       │    SQLite: Insert runs/events/transitions
       │    JSONL: Append records
       │
       └─→ Return Result
            {
              run_id,
              status,
              classification,
              risk,
              priority,
              confidence,
              state_history,
              tool_calls,
              decision_trace,
              execution_time_ms
            }
```

## Error Handling

**Error Categories:**
1. **Input Validation Errors**
   - Too short/long
   - Invalid format
   - Action: STATE → NEED_MORE_INFO

2. **Processing Errors**
   - ML inference fails
   - Risk calculation error
   - Action: STATE → ERROR, log error

3. **System Errors**
   - Database down
   - Disk space issues
   - Action: STATE → ERROR, alert

4. **Logical Errors**
   - Invalid transition
   - Data inconsistency
   - Action: STATE → ERROR, investigate

**Error Recovery:**
- Graceful degradation
- Escalation as fallback
- Manual review available
- Full audit trail for debugging

## Performance Characteristics

**Per Ticket:**
- Input validation: <1ms
- ML classification: 20-50ms
- Risk scoring: 5-10ms
- Priority assignment: <1ms
- Confidence check: <1ms
- Logging: 5-10ms
- **Total: <100ms average**

**System:**
- Model load: ~500ms (one-time on startup)
- Database init: ~100ms (one-time)
- Database write: 5-10ms per query
- JSONL write: <5ms per record

**Constraints:**
- Max concurrent: Limited by Streamlit
- Max database connections: 1 per thread
- Max state transitions: 20 (configurable)
- Memory: ~100MB typical

## Extension Points

### Adding New Category

1. Update `tools.py` Category enum
2. Add to `baseline.py` keywords
3. Add training examples to `ml_model.py`
4. Add to `risk_engine.py` base weights
5. Retrain model

### Adding New Tool

1. Define Input/Output in `tools.py`
2. Implement in `orchestrator.py`
3. Add state transition if needed
4. Add to evaluation scenarios
5. Test in UI

### Adding New Metric

1. Add to `metrics.py` Metrics class
2. Implement calculation method
3. Update UI component
4. Add to dashboard

## Security Considerations

- ✅ SQL injection prevention (parameterized queries)
- ✅ Input validation (length, format)
- ✅ No secrets in code (config external)
- ✅ No model extraction (binary pkl)
- ✅ Thread-safe logging (mutex locks)
- ✅ User override capability
- ✅ Audit trail for compliance

## Testing Strategy

**Unit Tests:**
- State machine transitions
- Risk calculation formula
- Confidence scoring

**Integration Tests:**
- End-to-end workflow
- Database operations
- ML model inference

**System Tests:**
- 12 evaluation scenarios
- Baseline comparison
- Performance benchmarks

**UI Tests:**
- Manual browser testing
- Responsive design check
- Animation smoothness

## Deployment

**Prerequisites:**
- Python 3.11+
- 500MB disk space
- 200MB RAM

**Steps:**
1. Clone repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run app: `streamlit run app.py`
4. Access: http://localhost:8501

**Production Considerations:**
- Use Streamlit Cloud or Docker
- Configure database backups
- Set up monitoring
- Create admin panel
- Implement rate limiting
- Add authentication

## Monitoring & Alerts

**Key Metrics:**
- Processing time per ticket
- Classification accuracy
- Escalation rate
- Error rate
- Database size

**Alerts:**
- Processing time > 1 second
- Classification accuracy drop
- Database errors
- Disk space warnings

---

**Version:** 1.0.0
**Last Updated:** February 27, 2026
**Status:** Production Ready
