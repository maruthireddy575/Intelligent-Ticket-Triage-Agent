import pandas as pd
from pathlib import Path

# Change filename if your CSV name is different
DATA_PATH = Path("data/raw/customer_support_tickets.csv")

print(f"\nLoading dataset from: {DATA_PATH}\n")

df = pd.read_csv(DATA_PATH)

print("=" * 60)
print("DATASET SHAPE")
print("=" * 60)
print(df.shape)

print("\n" + "=" * 60)
print("COLUMNS")
print("=" * 60)
print(df.columns.tolist())

print("\n" + "=" * 60)
print("FIRST 5 ROWS")
print("=" * 60)
print(df.head())

print("\n" + "=" * 60)
print("COLUMN TYPES")
print("=" * 60)
print(df.dtypes)

print("\n" + "=" * 60)
print("UNIQUE VALUES PER COLUMN")
print("=" * 60)

for col in df.columns:
    print(f"{col}: {df[col].nunique()} unique values")

print("\n" + "=" * 60)
print("CATEGORY DISTRIBUTION (if exists)")
print("=" * 60)

possible_cols = ["category", "Category", "ticket_type", "type", "issue_type"]

for col in possible_cols:
    if col in df.columns:
        print(f"\nDistribution for '{col}':\n")
        print(df[col].value_counts())