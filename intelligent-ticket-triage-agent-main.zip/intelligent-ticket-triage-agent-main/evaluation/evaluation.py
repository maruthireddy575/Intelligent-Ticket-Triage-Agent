
"""Final fixed evaluation harness with correct category mappings."""

import json
from pathlib import Path
from typing import List, Dict, Any
from src.metrics import Metrics
from src.baseline import BaselineClassifier
from src.tools import Category

# Print available categories for debugging
print("✅ Using categories:", [cat.value for cat in Category])

# Mapping function to convert model predictions to valid Category enum values
def map_to_category(prediction):
    """
    Map model prediction strings to valid Category enum values.
    Based on actual categories: bug, feature_request, documentation, infrastructure, security, performance, unclear
    """
    prediction_lower = prediction.lower() if prediction else ""
    
    # Define mappings based on your actual categories
    mappings = {
        # Bug mappings
        'bug': Category.BUG.value,
        'error': Category.BUG.value,
        'crash': Category.BUG.value,
        'technical': Category.BUG.value,
        'technical issue': Category.BUG.value,
        'issue': Category.BUG.value,
        'problem': Category.BUG.value,
        'fix': Category.BUG.value,
        'broken': Category.BUG.value,
        
        # Feature Request mappings
        'feature': Category.FEATURE_REQUEST.value,
        'feature_request': Category.FEATURE_REQUEST.value,
        'request': Category.FEATURE_REQUEST.value,
        'enhancement': Category.FEATURE_REQUEST.value,
        'suggestion': Category.FEATURE_REQUEST.value,
        'new': Category.FEATURE_REQUEST.value,
        'add': Category.FEATURE_REQUEST.value,
        
        # Documentation mappings
        'documentation': Category.DOCUMENTATION.value,
        'docs': Category.DOCUMENTATION.value,
        'manual': Category.DOCUMENTATION.value,
        'guide': Category.DOCUMENTATION.value,
        'tutorial': Category.DOCUMENTATION.value,
        'readme': Category.DOCUMENTATION.value,
        
        # Infrastructure mappings
        'infrastructure': Category.INFRASTRUCTURE.value,
        'server': Category.INFRASTRUCTURE.value,
        'database': Category.INFRASTRUCTURE.value,
        'network': Category.INFRASTRUCTURE.value,
        'deployment': Category.INFRASTRUCTURE.value,
        'hosting': Category.INFRASTRUCTURE.value,
        'cloud': Category.INFRASTRUCTURE.value,
        
        # Security mappings
        'security': Category.SECURITY.value,
        'vulnerability': Category.SECURITY.value,
        'hack': Category.SECURITY.value,
        'breach': Category.SECURITY.value,
        'authentication': Category.SECURITY.value,
        'password': Category.SECURITY.value,
        'login': Category.SECURITY.value,
        
        # Performance mappings
        'performance': Category.PERFORMANCE.value,
        'slow': Category.PERFORMANCE.value,
        'speed': Category.PERFORMANCE.value,
        'lag': Category.PERFORMANCE.value,
        'response time': Category.PERFORMANCE.value,
        'optimization': Category.PERFORMANCE.value,
        
        # Unclear mappings (catch-all)
        'general': Category.UNCLEAR.value,
        'question': Category.UNCLEAR.value,
        'help': Category.UNCLEAR.value,
        'support': Category.UNCLEAR.value,
    }
    
    # Try to find a match
    for key, value in mappings.items():
        if key in prediction_lower:
            return value
    
    # If no match, try to find any category that appears in the prediction
    for cat in Category:
        if cat.value in prediction_lower:
            return cat.value
    
    # Default fallback to UNCLEAR
    print(f"⚠️ Warning: Unknown category '{prediction}', defaulting to {Category.UNCLEAR.value}")
    return Category.UNCLEAR.value


class EvaluationHarness:
    """Harness for evaluating triage system against scenarios."""
    
    def __init__(self, scenarios_path: str = None):
        if scenarios_path is None:
            scenarios_path = Path(__file__).parent / "scenarios.json"
        
        with open(scenarios_path) as f:
            data = json.load(f)
        
        self.scenarios = data["scenarios"]
    
    def get_scenarios(self) -> List[Dict[str, Any]]:
        """Get all scenarios."""
        return self.scenarios
    
    def evaluate_ml_model(self, classifier_func, priority_func) -> Dict[str, Any]:
        """
        Evaluate ML model against all scenarios.
        """
        metrics = Metrics()
        
        for scenario in self.scenarios:
            subject = scenario["subject"]
            description = scenario["description"]
            expected_category = scenario["expected_category"]
            expected_priority = scenario["expected_priority"]
            
            # Classify
            predicted_category, confidence = classifier_func(subject, description)
            
            # Map the prediction to a valid Category enum value
            mapped_category = map_to_category(predicted_category)
            
            # Assign priority
            if expected_priority == "high":
                risk_score = 0.8
            elif expected_priority == "medium":
                risk_score = 0.5
            else:
                risk_score = 0.2
            
            predicted_priority = priority_func(mapped_category, risk_score)
            
            # Record
            metrics.record_result(
                predicted_category=mapped_category,
                true_category=expected_category,
                predicted_priority=predicted_priority.value,
                true_priority=expected_priority,
                confidence=confidence,
                escalated=False,
            )
        
        return {
            "model": "ml_model",
            "scenarios_tested": len(self.scenarios),
            "metrics": metrics.to_dict(),
            "detailed_results": self._get_detailed_results(
                self.scenarios, classifier_func, priority_func, metrics
            ),
        }
    
    def evaluate_baseline(self) -> Dict[str, Any]:
        """Evaluate baseline classifier."""
        baseline = BaselineClassifier()
        metrics = Metrics()
        
        for scenario in self.scenarios:
            subject = scenario["subject"]
            description = scenario["description"]
            expected_category = scenario["expected_category"]
            expected_priority = scenario["expected_priority"]
            
            # Classify with baseline
            predicted_category, confidence = baseline.classify_ticket(subject, description)
            predicted_priority = baseline.assign_priority(subject, description, predicted_category)
            
            metrics.record_result(
                predicted_category=predicted_category.value,
                true_category=expected_category,
                predicted_priority=predicted_priority.value,
                true_priority=expected_priority,
                confidence=confidence,
                escalated=False,
            )
        
        return {
            "model": "baseline",
            "scenarios_tested": len(self.scenarios),
            "metrics": metrics.to_dict(),
            "detailed_results": self._get_detailed_results_baseline(
                self.scenarios, baseline, metrics
            ),
        }
    
    def _get_detailed_results(self, scenarios, classifier_func, priority_func, metrics):
        """Get detailed per-scenario results."""
        results = []
        
        for scenario in scenarios:
            subject = scenario["subject"]
            description = scenario["description"]
            expected_category = scenario["expected_category"]
            
            predicted_category, confidence = classifier_func(subject, description)
            mapped_category = map_to_category(predicted_category)
            
            if scenario["expected_priority"] == "high":
                risk_score = 0.8
            elif scenario["expected_priority"] == "medium":
                risk_score = 0.5
            else:
                risk_score = 0.2
            
            predicted_priority = priority_func(mapped_category, risk_score)
            
            results.append({
                "scenario_id": scenario["id"],
                "subject": subject,
                "expected_category": expected_category,
                "predicted_category": mapped_category,
                "category_correct": mapped_category == expected_category,
                "confidence": confidence,
                "expected_priority": scenario["expected_priority"],
                "predicted_priority": predicted_priority.value,
                "priority_correct": predicted_priority.value == scenario["expected_priority"],
                "reason": scenario["reason"],
            })
        
        return results
    
    def _get_detailed_results_baseline(self, scenarios, baseline, metrics):
        """Get detailed per-scenario results for baseline."""
        results = []
        
        for scenario in scenarios:
            subject = scenario["subject"]
            description = scenario["description"]
            expected_category = scenario["expected_category"]
            
            predicted_category, confidence = baseline.classify_ticket(subject, description)
            predicted_priority = baseline.assign_priority(subject, description, predicted_category)
            
            results.append({
                "scenario_id": scenario["id"],
                "subject": subject,
                "expected_category": expected_category,
                "predicted_category": predicted_category.value,
                "category_correct": predicted_category.value == expected_category,
                "confidence": confidence,
                "expected_priority": scenario["expected_priority"],
                "predicted_priority": predicted_priority.value,
                "priority_correct": predicted_priority.value == scenario["expected_priority"],
                "reason": scenario["reason"],
            })
        
        return results
    
    def compare_models(self, ml_results: Dict[str, Any], baseline_results: Dict[str, Any]) -> Dict[str, Any]:
        """Compare ML model results with baseline."""
        ml_metrics = ml_results["metrics"]
        baseline_metrics = baseline_results["metrics"]
        
        return {
            "ml_model": {
                "classification_accuracy": ml_metrics["classification_accuracy"],
                "priority_accuracy": ml_metrics["priority_accuracy"],
                "end_to_end_accuracy": ml_metrics["end_to_end_accuracy"],
            },
            "baseline": {
                "classification_accuracy": baseline_metrics["classification_accuracy"],
                "priority_accuracy": baseline_metrics["priority_accuracy"],
                "end_to_end_accuracy": baseline_metrics["end_to_end_accuracy"],
            },
            "improvement": {
                "classification_accuracy": ml_metrics["classification_accuracy"] - baseline_metrics["classification_accuracy"],
                "priority_accuracy": ml_metrics["priority_accuracy"] - baseline_metrics["priority_accuracy"],
                "end_to_end_accuracy": ml_metrics["end_to_end_accuracy"] - baseline_metrics["end_to_end_accuracy"],
            },
        }
