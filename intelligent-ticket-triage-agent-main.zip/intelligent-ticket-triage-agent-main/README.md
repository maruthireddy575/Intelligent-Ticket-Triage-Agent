# intelligent-ticket-triage-agent
Agentic ML system for support ticket classification and intelligent risk-based priority assignment with explicit state machine and observability.
