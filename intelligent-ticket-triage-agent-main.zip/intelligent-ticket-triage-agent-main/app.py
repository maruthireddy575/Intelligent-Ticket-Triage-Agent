"""Main Streamlit app for Intelligent Ticket Triage Agent - Final Edition."""

import streamlit as st
import time
import base64
from pathlib import Path
from datetime import datetime
import json

# Local imports
from src.orchestrator import TriageOrchestrator
from src.config import get_config
from src.ml_model import get_model
from src.logger import TriageLogger
from src.baseline import BaselineClassifier
from src.risk_engine import RiskEngine
from src.tools import Priority
from evaluation.evaluation import EvaluationHarness
from ui.theme import CUSTOM_CSS, STATE_COLORS, PRIORITY_COLORS, get_state_badge, get_priority_badge
from ui.components import (
    render_state_timeline, render_classification_result, render_risk_analysis,
    render_priority_result, render_confidence_gauge, render_tool_calls,
    render_metrics_dashboard, render_decision_trace, render_final_result
)


# Page configuration
st.set_page_config(
    page_title="Intelligent Ticket Triage Agent",
    page_icon="🎫",
    layout="wide",
    initial_sidebar_state="expanded",
)


# =====================================================================
# SESSION STATE INITIALIZATION
# =====================================================================

if "processed_result" not in st.session_state:
    st.session_state.processed_result = None

if "config" not in st.session_state:
    st.session_state.config = get_config()

if "theme" not in st.session_state:
    st.session_state.theme = "light"

if "active_page" not in st.session_state:
    st.session_state.active_page = "New Ticket"

if "demo_subject" not in st.session_state:
    st.session_state.demo_subject = None

if "demo_description" not in st.session_state:
    st.session_state.demo_description = None

if "settings_updated" not in st.session_state:
    st.session_state.settings_updated = False


# =====================================================================
# GLASS MORPHISM CSS
# =====================================================================

GLASS_CSS = """
<style>
    /* Import modern font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    * {
        font-family: 'Inter', sans-serif;
    }
    
    /* New Ticket page specific title - UPDATED with ticket icon */
    .new-ticket-title {
        text-align: center;
        padding: 2rem 0;
        margin-bottom: 2rem;
        background: rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border-radius: 24px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
    }
    
    .title-icon {
        font-size: 4rem;
        animation: float 3s ease-in-out infinite;
        display: inline-block;
        margin-bottom: 0.5rem;
    }
    
    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }
    
    .title-text {
        font-size: 2.8rem;
        color:#1e293b;
        font-weight: 800;
        margin: 0;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        letter-spacing: -0.5px;
    }
    
    .title-subtext {
        font-size: 1.1rem;
        color: #1e293b;
        margin: 0.25rem 0 0 0;
    }
    
    /* Dark mode title text color */
    [data-theme="dark"] .title-subtext {
        color: #d1d5db !important;
    }
    
    /* Glass morphism effect for cards */
    .glass-card {
        background: rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        border-radius: 16px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        padding: 1.5rem;
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
        transition: all 0.3s ease;
        margin-bottom: 1rem;
        height: 100%;
    }
    
    .glass-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 48px 0 rgba(31, 38, 135, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.5);
    }
    
    /* Dark mode glass adjustments */
    [data-theme="dark"] .glass-card {
        background: rgba(0, 0, 0, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Page header for other pages - simple headings */
    .page-header {
        font-size: 2rem;
        font-weight: 600;
        margin: 1.5rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #667eea;
        color: #1f2937;
    }
    
    [data-theme="dark"] .page-header {
        color: #f3f4f6;
    }
    
    /* Sidebar glass styling */
    [data-testid="stSidebar"] {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border-right: 1px solid rgba(255, 255, 255, 0.2);
        padding: 2rem 1rem;
    }
    
    [data-theme="dark"] [data-testid="stSidebar"] {
        background: rgba(0, 0, 0, 0.25);
        border-right: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Button styling */
    .stButton > button {
        background: rgba(255, 255, 255, 0.2) !important;
        backdrop-filter: blur(5px) !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px !important;
        color: #1f2937 !important;
        font-weight: 600 !important;
        transition: all 0.3s ease !important;
        width: 100%;
    }
    
    .stButton > button:hover {
        background: rgba(255, 255, 255, 0.3) !important;
        transform: translateY(-2px) !important;
        border: 1px solid rgba(255, 255, 255, 0.5) !important;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1) !important;
    }
    
    [data-theme="dark"] .stButton > button {
        background: rgba(0, 0, 0, 0.2) !important;
        color: #f3f4f6 !important;
    }
    
    /* Metric cards */
    div[data-testid="stMetric"] {
        background: rgba(255, 255, 255, 0.2) !important;
        backdrop-filter: blur(5px) !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 16px !important;
        padding: 1rem !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05) !important;
    }
    
    [data-theme="dark"] div[data-testid="stMetric"] {
        background: rgba(0, 0, 0, 0.2) !important;
    }
    
    /* Input fields */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stSelectbox > div > div,
    .stNumberInput > div > div > input {
        background: rgba(255, 255, 255, 0.2) !important;
        backdrop-filter: blur(5px) !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px !important;
        color: #1f2937 !important;
    }
    
    [data-theme="dark"] .stTextInput > div > div > input,
    [data-theme="dark"] .stTextArea > div > div > textarea,
    [data-theme="dark"] .stSelectbox > div > div,
    [data-theme="dark"] .stNumberInput > div > div > input {
        background: rgba(0, 0, 0, 0.2) !important;
        color: #f3f4f6 !important;
    }
    
    /* Progress bar */
    .stProgress > div > div {
        background: linear-gradient(90deg, #667eea, #764ba2) !important;
        border-radius: 9999px !important;
    }
    
    /* Slider */
    .stSlider > div {
        background: rgba(255, 255, 255, 0.2) !important;
        backdrop-filter: blur(5px) !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px !important;
        padding: 1rem !important;
    }
    
    /* Checkbox */
    .stCheckbox {
        background: rgba(255, 255, 255, 0.2) !important;
        backdrop-filter: blur(5px) !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        border-radius: 12px !important;
        padding: 0.5rem !important;
        margin-bottom: 1rem;
    }
    
    /* Main content area - ensure wide layout */
    .main .block-container {
        max-width: 100%;
        padding: 1rem 2rem;
    }
    
    /* Column layouts */
    div[data-testid="column"] {
        padding: 0 0.5rem;
    }
    
    /* Divider styling */
    .custom-divider {
        margin: 2rem 0;
        border: none;
        height: 1px;
        background: linear-gradient(90deg, transparent, #667eea, transparent);
    }
</style>
"""

# =====================================================================
# THEME CSS (Light/Dark)
# =====================================================================

if st.session_state.theme == "dark":
    THEME_CSS = """
    <style>
        [data-theme="dark"] {
            color-scheme: dark;
        }
        
        .stApp {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }
        
        h1, h2, h3, h4, h5, h6, p, span, div {
            color: #f3f4f6 !important;
        }
        
        .stMarkdown, .stText {
            color: #f3f4f6 !important;
        }
    </style>
    """
else:
    THEME_CSS = """
    <style>
        [data-theme="light"] {
            color-scheme: light;
        }
        
        .stApp {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
        }
        
        h1, h2, h3, h4, h5, h6, p, span, div {
            color: #1f2937 !important;
        }
    </style>
    """

# Apply all CSS
st.markdown(f"{THEME_CSS}{GLASS_CSS}{CUSTOM_CSS}", unsafe_allow_html=True)
st.markdown(f'<div data-theme="{st.session_state.theme}">', unsafe_allow_html=True)


# ============================================================================
# SIDEBAR - Clean navigation
# ============================================================================

with st.sidebar:
    st.markdown("""
    <div style="text-align: center; margin-bottom: 2rem;">
        <div style="font-size: 2.5rem;">🎫</div>
        <h3 style="margin: 0;">Ticket Triage</h3>
    </div>
    """, unsafe_allow_html=True)
    
    # Simple navigation buttons
    if st.button("📥 New Ticket", use_container_width=True, key="nav_new"):
        st.session_state.active_page = "New Ticket"
        st.rerun()
    
    if st.button("📊 Analytics", use_container_width=True, key="nav_analytics"):
        st.session_state.active_page = "Analytics"
        st.rerun()
    
    if st.button("🧪 Evaluation", use_container_width=True, key="nav_evaluation"):
        st.session_state.active_page = "Evaluation"
        st.rerun()
    
    if st.button("📋 Logs", use_container_width=True, key="nav_logs"):
        st.session_state.active_page = "Logs"
        st.rerun()
    
    if st.button("⚙️ Settings", use_container_width=True, key="nav_settings"):
        st.session_state.active_page = "Settings"
        st.rerun()
    
    st.markdown("---")
    
    # Theme toggle
    theme_icon = "🌙" if st.session_state.theme == "light" else "☀️"
    theme_text = "Dark Mode" if st.session_state.theme == "light" else "Light Mode"
    if st.button(f"{theme_icon} {theme_text}", use_container_width=True):
        st.session_state.theme = "dark" if st.session_state.theme == "light" else "light"
        st.rerun()
    
    st.markdown("---")
    st.caption("v1.0.0 | Engineering-Grade")


# ============================================================================
# NEW TICKET PAGE - With title color fixed
# ============================================================================

if st.session_state.active_page == "New Ticket":
    
    # Glass morphism title box with ticket icon
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.25); 
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                border-radius: 24px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 2rem;
                margin: 1rem 0 2rem 0;
                box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
                text-align: center;">
        <div style="font-size: 4rem; margin-bottom: 0.5rem; animation: float 3s ease-in-out infinite;">🎫</div>
        <h1 style="font-size: 2.8rem; font-weight: 700; margin: 0; 
                   ">INTELLIGENT TICKET TRIAGE AGENT</h1>
        <p style="font-size: 1rem; color: #4b5563; margin: 0.5rem 0 0 0;">Submit your ticket for AI-powered analysis</p>
    </div>
    
    <style>
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Create two columns for the ticket submission form
    col1, col2 = st.columns(2, gap="large")
    
    with col1:
        # Ticket Information Card
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown("### 📝 New Ticket")
        
        # Check for demo data first
        if st.session_state.demo_subject:
            default_subject = st.session_state.demo_subject
            default_description = st.session_state.demo_description
            st.session_state.demo_subject = None
            st.session_state.demo_description = None
        else:
            default_subject = ""
            default_description = ""
        
        # Subject input
        subject = st.text_input(
            "**Ticket Subject**",
            value=default_subject,
            placeholder="Briefly describe the issue...",
            max_chars=200,
            key="subject_input"
        )
        
        # Description input
        description = st.text_area(
            "**Ticket Description**",
            value=default_description,
            placeholder="Provide detailed information about the issue...",
            height=150,
            max_chars=5000,
            key="description_input"
        )
        
        st.caption("*Press Ctrl+Enter to apply.*")
        
        st.markdown("</div>", unsafe_allow_html=True)
    
    with col2:
        # Input Metrics Card
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown("### 📊 Input Metrics")
        
        # Subject metric
        if subject:
            st.caption(f"Subject: {len(subject)}/200 characters")
            st.progress(min(len(subject)/200, 1.0))
        else:
            st.caption("Subject: 0/200 characters")
            st.progress(0.0)
        
        # Description metric
        if description:
            st.caption(f"Description: {len(description)}/5000 characters")
            st.progress(min(len(description)/5000, 1.0))
        else:
            st.caption("Description: 0/5000 characters")
            st.progress(0.0)
        
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Action Buttons Card
       
        
        escalation_override = st.checkbox(
            "🚨 Force Escalation",
            value=False,
            help="Override confidence check and force escalation",
            key="escalation_check"
        )
        
        analyze_button = st.button(
            "🚀 Analyze Ticket",
            use_container_width=True,
            type="primary",
            key="analyze_btn"
        )
        
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Demo Button Card
       
        if st.button("🎬 Load Demo Ticket", use_container_width=True, key="demo_btn"):
            st.session_state.demo_subject = "Database server down - Production outage"
            st.session_state.demo_description = "CRITICAL: The database server is offline. All services cannot access the database. This is causing a full production outage. Customers cannot access the application. Please escalate immediately!"
        st.markdown("</div>", unsafe_allow_html=True)
    
    # Process ticket
    if analyze_button and subject and description:
        with st.spinner("Processing ticket through triage pipeline..."):
            orchestrator = TriageOrchestrator()
            result = orchestrator.process_ticket(
                subject=subject,
                description=description,
                escalation_override=escalation_override,
            )
            st.session_state.processed_result = result
            st.rerun()
    
    # Display result with detailed analysis
    if st.session_state.processed_result:
        result = st.session_state.processed_result
        
        st.markdown("---")
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown("### 🎯 Triage Results")
        render_final_result(result)
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Detailed analysis expander (expanded by default)
        with st.expander("🔍 View Detailed Analysis", expanded=True):
            col1, col2 = st.columns(2)
            
            with col1:
                if result["classification"]:
                    
                   
                    render_classification_result(result["classification"])
                    st.markdown('</div>', unsafe_allow_html=True)
                
                if result["priority"]:
                    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                  
                    render_priority_result(result["priority"])
                    st.markdown('</div>', unsafe_allow_html=True)
            
            with col2:
                if result["risk"]:
                    
                  
                    render_risk_analysis(result["risk"])
                    st.markdown('</div>', unsafe_allow_html=True)
                
                if result["confidence"]:
                    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
                    
                    render_confidence_gauge(result["confidence"])
                    st.markdown('</div>', unsafe_allow_html=True)
            
            # State machine timeline
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
           
            render_state_timeline(result.get("state_history", []))
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Tool execution trace
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
         
            render_tool_calls(result.get("tool_calls", []))
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Decision trace
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
         
            render_decision_trace(result["decision_trace"])
            st.markdown('</div>', unsafe_allow_html=True)
        
        # Download report
        col1, col2 = st.columns(2)
        with col1:
            if st.button("📥 Download JSON Report", use_container_width=True):
                json_data = json.dumps(result, indent=2, default=str)
                st.download_button(
                    label="Download JSON",
                    data=json_data,
                    file_name=f"triage_report_{result['run_id']}.json",
                    mime="application/json",
                )


# ============================================================================
# ANALYTICS PAGE - Glass morphism only on header with enhanced visualizations
# ============================================================================

elif st.session_state.active_page == "Analytics":
    
    # Glass morphism ONLY for the header
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.25); 
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 1.5rem 2rem;
                margin: 1rem 0 2rem 0;
                box-shadow: 0 4px 16px 0 rgba(31, 38, 135, 0.15);
                text-align: center;
                width: 100%;">
        <h1 style="font-size: 2.5rem; font-weight: 600; margin: 0; color: #1e293b;">📊 Analytics Dashboard</h1>
    </div>
    """, unsafe_allow_html=True)
    
    logger = TriageLogger()
    runs = logger.get_all_runs(limit=1000)  # Get more runs for better analysis
    
    if runs:
        # Convert to DataFrame for easier analysis
        import pandas as pd
        import plotly.express as px
        import plotly.graph_objects as go
        from datetime import datetime
        
        df = pd.DataFrame(runs)
        
        # Ensure timestamp is datetime
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Filters section
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("### 📅 Date Range")
            date_range = st.date_input(
                "Select date range",
                value=(df['timestamp'].min().date(), df['timestamp'].max().date()),
                key="date_range"
            )
        
        with col2:
            st.markdown("### 🏷️ Category Filter")
            all_categories = df['predicted_category'].unique().tolist()
            selected_categories = st.multiselect(
                "Select categories",
                options=all_categories,
                default=all_categories,
                key="category_filter"
            )
        
        with col3:
            st.markdown("### ⚡ Priority Filter")
            all_priorities = df['predicted_priority'].unique().tolist()
            selected_priorities = st.multiselect(
                "Select priorities",
                options=all_priorities,
                default=all_priorities,
                key="priority_filter"
            )
        
        # Apply filters
        filtered_df = df[
            (df['predicted_category'].isin(selected_categories)) &
            (df['predicted_priority'].isin(selected_priorities))
        ]
        
        if len(date_range) == 2:
            start_date, end_date = date_range
            filtered_df = filtered_df[
                (filtered_df['timestamp'].dt.date >= start_date) &
                (filtered_df['timestamp'].dt.date <= end_date)
            ]
        
        st.markdown("---")
        
        # Key Metrics Row
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_runs = len(filtered_df)
            st.metric("Total Tickets", total_runs, delta=None)
        
        with col2:
            escalated = filtered_df['escalated'].sum() if 'escalated' in filtered_df.columns else 0
            escalation_rate = (escalated / total_runs * 100) if total_runs > 0 else 0
            st.metric("Escalated", f"{escalated}", delta=f"{escalation_rate:.1f}%")
        
        with col3:
            avg_confidence = filtered_df['confidence'].mean() if total_runs > 0 else 0
            st.metric("Avg Confidence", f"{avg_confidence:.1%}", delta=None)
        
        with col4:
            avg_risk = filtered_df['risk_score'].mean() if total_runs > 0 else 0
            st.metric("Avg Risk", f"{avg_risk:.2f}", delta=None)
        
        st.markdown("---")
        
        # Visualizations Row 1 - Category and Priority Distributions
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📊 Category Distribution")
            
            # Category counts
            cat_counts = filtered_df['predicted_category'].value_counts().reset_index()
            cat_counts.columns = ['Category', 'Count']
            
            # Create pie chart
            fig_pie = px.pie(
                cat_counts, 
                values='Count', 
                names='Category',
                title='Ticket Categories',
                color_discrete_sequence=px.colors.qualitative.Set3,
                hole=0.4
            )
            fig_pie.update_traces(textposition='inside', textinfo='percent+label')
            fig_pie.update_layout(
                height=400,
                showlegend=True,
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)'
            )
            st.plotly_chart(fig_pie, use_container_width=True)
        
        with col2:
            st.markdown("### ⚡ Priority Distribution")
            
            # Priority counts
            priority_counts = filtered_df['predicted_priority'].value_counts().reset_index()
            priority_counts.columns = ['Priority', 'Count']
            
            # Define colors for priorities
            priority_colors = {
                'high': '#ef4444',
                'medium': '#f59e0b',
                'low': '#10b981'
            }
            
            # Create bar chart
            fig_bar = px.bar(
                priority_counts,
                x='Priority',
                y='Count',
                title='Ticket Priorities',
                color='Priority',
                color_discrete_map=priority_colors,
                text='Count'
            )
            fig_bar.update_traces(textposition='outside', textfont_size=14)
            fig_bar.update_layout(
                height=400,
                showlegend=False,
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                xaxis_title="",
                yaxis_title="Number of Tickets"
            )
            st.plotly_chart(fig_bar, use_container_width=True)
        
        st.markdown("---")
        
        # Visualizations Row 2 - Time Series Analysis
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📈 Ticket Volume Over Time")
            
            # Group by date
            df['date'] = df['timestamp'].dt.date
            daily_counts = df.groupby('date').size().reset_index(name='count')
            
            # Create line chart
            fig_line = px.line(
                daily_counts,
                x='date',
                y='count',
                title='Daily Ticket Volume',
                markers=True
            )
            fig_line.update_traces(line_color='#667eea', line_width=3, marker_size=8)
            fig_line.update_layout(
                height=400,
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                xaxis_title="Date",
                yaxis_title="Number of Tickets",
                hovermode='x unified'
            )
            st.plotly_chart(fig_line, use_container_width=True)
        
        with col2:
            st.markdown("### 📊 Confidence Trends")
            
            # Calculate average confidence by date
            daily_confidence = df.groupby('date')['confidence'].mean().reset_index()
            daily_confidence.columns = ['date', 'avg_confidence']
            
            # Create line chart for confidence trends
            fig_confidence = px.line(
                daily_confidence,
                x='date',
                y='avg_confidence',
                title='Average Confidence Over Time',
                markers=True
            )
            fig_confidence.update_traces(line_color='#10b981', line_width=3, marker_size=8)
            fig_confidence.update_layout(
                height=400,
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                xaxis_title="Date",
                yaxis_title="Average Confidence",
                hovermode='x unified'
            )
            # Add threshold line
            fig_confidence.add_hline(y=0.75, line_dash="dash", line_color="red", 
                                    annotation_text="Threshold", annotation_position="top right")
            st.plotly_chart(fig_confidence, use_container_width=True)
        
        st.markdown("---")
        
        # Recent Runs Table with enhanced styling
        st.markdown("### 📋 Recent Tickets")
        
        display_data = []
        for run in filtered_df.sort_values('timestamp', ascending=False).head(20).to_dict('records'):
            # Format priority with color
            priority = run['predicted_priority'].upper()
            priority_color = {
                'HIGH': '#ef4444',
                'MEDIUM': '#f59e0b',
                'LOW': '#10b981'
            }.get(priority, '#6b7280')
            
            display_data.append({
                "Time": run['timestamp'].strftime('%Y-%m-%d %H:%M') if pd.notna(run['timestamp']) else 'N/A',
                "Category": run['predicted_category'].upper(),
                "Priority": priority,
                "Confidence": f"{run['confidence']:.1%}",
                "Risk": f"{run['risk_score']:.2f}",
                "Escalated": "✅" if run.get('escalated', False) else "❌",
            })
        
        if display_data:
            # Create a DataFrame for display
            display_df = pd.DataFrame(display_data)
            st.dataframe(
                display_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Time": st.column_config.TextColumn("Time"),
                    "Category": st.column_config.TextColumn("Category"),
                    "Priority": st.column_config.TextColumn("Priority"),
                    "Confidence": st.column_config.TextColumn("Confidence"),
                    "Risk": st.column_config.NumberColumn("Risk", format="%.2f"),
                    "Escalated": st.column_config.TextColumn("Escalated"),
                }
            )
        
        # Summary statistics
        st.markdown("---")
        st.markdown("### 📈 Summary Statistics")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # Top category
            top_category = filtered_df['predicted_category'].mode()[0] if not filtered_df.empty else 'N/A'
            st.markdown(f"""
            <div class="glass-card" style="text-align: center;">
                <h3 style="margin: 0; color: #4b5563;">🏆 Top Category</h3>
                <p style="font-size: 1.5rem; font-weight: 600; color: #667eea; margin: 0;">{top_category.upper()}</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            # Most common priority
            top_priority = filtered_df['predicted_priority'].mode()[0] if not filtered_df.empty else 'N/A'
            priority_color = {
                'high': '#ef4444',
                'medium': '#f59e0b',
                'low': '#10b981'
            }.get(top_priority, '#6b7280')
            st.markdown(f"""
            <div class="glass-card" style="text-align: center;">
                <h3 style="margin: 0; color: #4b5563;">⚡ Most Common Priority</h3>
                <p style="font-size: 1.5rem; font-weight: 600; color: {priority_color}; margin: 0;">{top_priority.upper()}</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            # Average execution time
            avg_time = filtered_df['execution_time_ms'].mean() if 'execution_time_ms' in filtered_df.columns else 0
            st.markdown(f"""
            <div class="glass-card" style="text-align: center;">
                <h3 style="margin: 0; color: #4b5563;">⏱️ Avg Processing Time</h3>
                <p style="font-size: 1.5rem; font-weight: 600; color: #8b5cf6; margin: 0;">{avg_time:.1f}ms</p>
            </div>
            """, unsafe_allow_html=True)
        
    else:
        st.info("No runs available yet. Submit a ticket to see analytics.")


# ============================================================================
# EVALUATION PAGE - Glass morphism only on header
# ============================================================================

elif st.session_state.active_page == "Evaluation":
    
    # Glass morphism ONLY for the header
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.25); 
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 1.5rem 2rem;
                margin: 1rem 0 2rem 0;
                box-shadow: 0 4px 16px 0 rgba(31, 38, 135, 0.15);
                text-align: center;
                width: 100%;">
        <h1 style="font-size: 2.5rem; font-weight: 600; margin: 0; color: #1e293b;">🧪 Evaluation</h1>
    </div>
    """, unsafe_allow_html=True)
    
    # Rest of the page content - NO glass morphism
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.markdown("### Settings")
        
        test_type = st.radio(
            "Test Type",
            ["Run All Scenarios", "Baseline Only", "Compare Models"],
            key="test_type"
        )
        
        if st.button("▶️ Run Evaluation", use_container_width=True, type="primary", key="run_eval"):
            with st.spinner("Running evaluation scenarios..."):
                harness = EvaluationHarness()
                
                # Get model functions
                model = get_model()
                risk_engine = RiskEngine()
                
                def model_classifier(subject, description):
                    text = f"{subject} {description}"
                    category, confidence, _ = model.predict_with_probs(text)
                    return category, confidence
                
                def model_priority(category, risk_score):
                    priority_str = risk_engine.get_priority_from_risk(risk_score)
                    return {
                        "high": Priority.HIGH,
                        "medium": Priority.MEDIUM,
                        "low": Priority.LOW,
                    }[priority_str]
                
                if test_type in ["Run All Scenarios", "Compare Models"]:
                    ml_results = harness.evaluate_ml_model(model_classifier, model_priority)
                
                if test_type in ["Baseline Only", "Compare Models"]:
                    baseline_results = harness.evaluate_baseline()
                
                if test_type == "Compare Models":
                    comparison = harness.compare_models(ml_results, baseline_results)
                    st.session_state.eval_results = {
                        "ml": ml_results,
                        "baseline": baseline_results,
                        "comparison": comparison,
                    }
                elif test_type == "Run All Scenarios":
                    st.session_state.eval_results = {"ml": ml_results}
                else:
                    st.session_state.eval_results = {"baseline": baseline_results}
    
    with col2:
        if "eval_results" in st.session_state:
            st.markdown("### Results")
            
            results = st.session_state.eval_results
            
            if "comparison" in results:
                comp = results["comparison"]
                improvement = comp.get("improvement", {})
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric(
                        "Classification",
                        f"{comp['ml_model']['classification_accuracy']:.1%}",
                        delta=f"{improvement.get('classification_accuracy', 0):+.1%}"
                    )
                with col2:
                    st.metric(
                        "Priority",
                        f"{comp['ml_model']['priority_accuracy']:.1%}",
                        delta=f"{improvement.get('priority_accuracy', 0):+.1%}"
                    )
                with col3:
                    st.metric(
                        "End-to-End",
                        f"{comp['ml_model']['end_to_end_accuracy']:.1%}",
                        delta=f"{improvement.get('end_to_end_accuracy', 0):+.1%}"
                    )
            
            if "ml" in results:
                ml_results = results["ml"]
                render_metrics_dashboard(ml_results["metrics"])
            
            if "baseline" in results:
                baseline_results = results["baseline"]
                render_metrics_dashboard(baseline_results["metrics"])


# ============================================================================
# LOGS PAGE - Glass morphism only on header
# ============================================================================

elif st.session_state.active_page == "Logs":
    
    # Glass morphism ONLY for the header
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.25); 
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 1.5rem 2rem;
                margin: 1rem 0 2rem 0;
                box-shadow: 0 4px 16px 0 rgba(31, 38, 135, 0.15);
                text-align: center;
                width: 100%;">
        <h1 style="font-size: 2.5rem; font-weight: 600; margin: 0; color: #1e293b;">📋 Logs</h1>
    </div>
    """, unsafe_allow_html=True)
    
    # Rest of the page content - NO glass morphism
    col1, col2 = st.columns([1, 3])
    
    with col1:
        st.markdown("### Filters")
        
        logger = TriageLogger()
        recent_runs = logger.get_all_runs(limit=50)
        run_ids = [r["id"] for r in recent_runs]
        
        selected_run_id = st.selectbox(
            "Select Run ID",
            run_ids if run_ids else ["No runs available"],
            index=0 if run_ids else None,
            key="run_selector"
        )
        
        log_type = st.radio(
            "Log Type",
            ["Summary", "State Transitions", "Tool Calls", "Events"],
            key="log_type"
        )
    
    with col2:
        if selected_run_id and selected_run_id != "No runs available":
            st.markdown(f"### Run: {selected_run_id[:8]}...")
            
            run = logger.get_run(selected_run_id)
            
            if run:
                if log_type == "Summary":
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Category", run["predicted_category"].upper())
                        st.metric("Priority", run["predicted_priority"].upper())
                        st.metric("Confidence", f"{run['confidence']:.1%}")
                    with col2:
                        st.metric("Risk Score", f"{run['risk_score']:.2f}")
                        st.metric("Escalated", "Yes" if run["escalated"] else "No")
                        st.metric("Time", f"{run['execution_time_ms']:.1f}ms")
                    
                    st.write("**Subject:**", run["subject"])
                    st.write("**Description:**", run["description"])
                
                elif log_type == "State Transitions":
                    transitions = logger.get_run_state_transitions(selected_run_id)
                    if transitions:
                        for t in transitions:
                            st.write(f"{t['previous_state']} → {t['next_state']}  ⏰ {t['timestamp']}")
                    else:
                        st.info("No state transitions")
                
                elif log_type == "Tool Calls":
                    tool_calls = logger.get_run_tool_calls(selected_run_id)
                    if tool_calls:
                        for tool_call in tool_calls:
                            with st.expander(f"{tool_call['tool_name']}"):
                                st.json(tool_call)
                    else:
                        st.info("No tool calls")
                
                elif log_type == "Events":
                    events = logger.get_run_events(selected_run_id)
                    if events:
                        for event in events:
                            st.write(f"**{event['event_type']}** - {event['timestamp']}")
                    else:
                        st.info("No events")


# ============================================================================
# SETTINGS PAGE - Glass morphism only on header
# ============================================================================

elif st.session_state.active_page == "Settings":
    
    # Glass morphism ONLY for the header
    st.markdown("""
    <div style="background: rgba(255, 255, 255, 0.25); 
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                padding: 1.5rem 2rem;
                margin: 1rem 0 2rem 0;
                box-shadow: 0 4px 16px 0 rgba(31, 38, 135, 0.15);
                text-align: center;
                width: 100%;">
        <h1 style="font-size: 2.5rem; font-weight: 600; margin: 0; color: #1e293b;">⚙️ Settings</h1>
    </div>
    """, unsafe_allow_html=True)
    
    # Rest of the page content - NO glass morphism
    col1, col2 = st.columns(2, gap="large")
    
    with col1:
        st.markdown("### Model Configuration")
        
        confidence_threshold = st.slider(
            "Confidence Threshold",
            min_value=0.0,
            max_value=1.0,
            value=st.session_state.config.confidence_threshold,
            step=0.05,
            help="Tickets below this confidence are escalated",
            key="settings_conf"
        )
        
        seed = st.number_input(
            "Random Seed",
            min_value=0,
            max_value=10000,
            value=st.session_state.config.seed,
            help="For reproducible results",
            key="settings_seed"
        )
    
    with col2:
        st.markdown("### System Preferences")
        
        auto_refresh = st.checkbox(
            "Auto-refresh dashboard",
            value=False,
            help="Automatically refresh data"
        )
        
        show_animations = st.checkbox(
            "Show animations",
            value=True,
            help="Enable UI animations"
        )
        
        debug_mode = st.checkbox(
            "Debug mode",
            value=False,
            help="Show debug information"
        )
    
    # Save settings button
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("💾 Save Settings", use_container_width=True, type="primary", key="save_settings"):
            from src.config import TriageConfig, set_config
            new_config = TriageConfig(
                confidence_threshold=confidence_threshold,
                seed=seed,
                max_steps=st.session_state.config.max_steps,
                risk_weights=st.session_state.config.risk_weights,
            )
            set_config(new_config)
            st.session_state.config = new_config
            st.session_state.settings_updated = True
            st.rerun()
    
    if st.session_state.settings_updated:
        st.success("✅ Settings saved successfully!")
        st.session_state.settings_updated = False


# ============================================================================
# FOOTER
# ============================================================================

st.markdown("---")
st.markdown("""
<div style="text-align: center; padding: 1rem; color: #6b7280; font-size: 0.9rem;">
    Intelligent Ticket Triage Agent | Engineering-Grade System | Powered by Machine Learning
</div>
""", unsafe_allow_html=True)

st.markdown('</div>', unsafe_allow_html=True)  # Close theme div