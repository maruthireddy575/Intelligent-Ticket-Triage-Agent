
from src.orchestrator import TriageOrchestrator
import json

# Process a test ticket
orchestrator = TriageOrchestrator()
result = orchestrator.process_ticket(
    subject="Database server down",
    description="The database is offline, production outage",
    escalation_override=False
)

print("="*60)
print("RESULT STRUCTURE")
print("="*60)
print(json.dumps(result, indent=2, default=str))

print("\n" + "="*60)
print("KEYS IN RESULT:")
print("="*60)
for key in result.keys():
    print(f"  - {key}")
